# Original evidence for a fixed Motionwright candidate

Source: 79929a71173d8f56422007ed944c7d6db42d879f.

The retained original CI output supports twenty selected migration methods, seven selected report-safety methods, nine generated benchmark datasets, and four platform-specific package inspections. Read review/observations.json for the exact source spans, original log lines, and limits. Dataset operations and GUI launches are not added to the named-test count.

Run python -B verify.py to check this audit subset. To rehash the complete retained original CI archives as well, run python -B verify.py --original-artifacts-dir PATH_TO_ORIGINAL_ARCHIVES. The expected artifact filenames and API digests are in review/original-archives.json. This bundle contains observations and source; installer payloads remain in the separately retained originals.

The checker performs no product execution, installation, rendering, publication, or acceptance promotion. A successful custody check means the retained evidence is internally consistent; human review, distribution signing, macOS notarization, and the full product remain separate questions.
