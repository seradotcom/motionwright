from pathlib import Path
import argparse,hashlib,json,zipfile
def sha(b):return hashlib.sha256(b).hexdigest()
def jl(p):return json.loads(p.read_bytes())
ap=argparse.ArgumentParser();ap.add_argument('--original-artifacts-dir',type=Path);args=ap.parse_args()
root=Path(__file__).resolve().parent
m=jl(root/'manifest.json');expected={x['path']:x for x in m['files']}
actual={p.relative_to(root).as_posix()for p in root.rglob('*')if p.is_file()and p.name!='manifest.json'}
assert actual==set(expected),(actual-set(expected),set(expected)-actual)
for rel,x in expected.items():
 b=(root/rel).read_bytes();assert len(b)==x['bytes']and sha(b)==x['sha256'],rel
obs=jl(root/'review/observations.json');assert obs['source_sha']=='79929a71173d8f56422007ed944c7d6db42d879f'
for key,jid,n in [('migration',120258926504,20),('performance',120257925140,7)]:
 cases=obs[key];assert len(cases)==n and len({x['selector']for x in cases})==n
 lines=(root/f'original/job-{jid}.log').read_text(encoding='utf-8').splitlines()
 for x in cases:
  v=x['success'];assert lines[v['line']-1]==v['raw']and v['raw'].endswith('... ok')
  d=x['definition'];raw=(root/'source'/d['path']).read_bytes();assert sha(raw)==d['file_sha256']
  body=''.join(raw.decode().splitlines(keepends=True)[d['start_line']-1:d['end_line']])
  assert sha(body.encode())==d['body_sha256']
r=jl(root/'original/artifact-members/12480568992/report.json')
assert r['source_sha']==obs['source_sha']and r['datasets']==len(r['results'])==9
assert all(x['revision_delta']==10 and len(x['operations'])==10 for x in r['results'])
assert r['human_feedback'].startswith('NOT_RUN:')
assert len(obs['package_observations'])==4
for q in obs['package_observations']:
 x=q['observation'];assert x['candidate']['source_revision']==obs['source_sha']
 assert x['claims']['human_install_acceptance']=='NOT_RUN'and not x['claims']['release_published']
assert b'level="asInvoker"'in(root/'original/nsis-RT_MANIFEST.xml').read_bytes()
verified=0
if args.original_artifacts_dir:
 for a in jl(root/'review/original-archives.json'):
  p=args.original_artifacts_dir/a['filename'];b=p.read_bytes()
  assert len(b)==a['bytes']and sha(b)==a['sha256']and a['api_digest']=='sha256:'+sha(b)
  with zipfile.ZipFile(p)as z:
   actual=[i.filename for i in z.infolist()if not i.is_dir()]
   assert set(actual)=={x['name']for x in a['members']}
   for x in a['members']:
    raw=z.read(x['name']);assert len(raw)==x['bytes']and sha(raw)==x['sha256']
  verified+=1
print(json.dumps({'custody_validation':'PASS','original_archives_rehashed':verified,'selected_named_methods':27,'datasets':9,'package_inspections':4,'new_product_tests':0,'human_acceptance':False,'release_authorized':False},sort_keys=True))
