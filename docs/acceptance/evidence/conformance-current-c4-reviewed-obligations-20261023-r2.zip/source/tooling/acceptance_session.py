#!/usr/bin/env python3
"""Private, source-bound intake for Motionwright's 60 independent acceptance cases.

This tool does not contain private acceptance scenario text. It NEVER promotes
an implementation CI result to PASS, edits the public acceptance ledger, or
authenticates the claimed reviewer identity.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone, timedelta
from functools import lru_cache
from hashlib import sha256
import json
import os
import stat
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import uuid

ROOT = Path(__file__).resolve().parents[1]
CANONICAL = ROOT / "docs" / "acceptance" / "acceptance-status.json"
LOCK = ROOT / "SOURCE_LOCK.json"
EXPECTED_IDS = [f"ACC-{i:03d}" for i in range(1, 61)]
STATES = {"NOT_RUN", "PASS", "FAIL", "BLOCKED"}
SHA_RE = re.compile(r"^[0-9a-f]{40}$")
DIGEST_RE = re.compile(r"^[0-9a-f]{64}$")
MAX_EVIDENCE_BYTES = 2 * 1024 * 1024 * 1024
SCHEMA = 1
MAX_MANIFEST_BYTES = 8 * 1024 * 1024


class IntakeError(ValueError):
    pass


def _strict_json_object(pairs: list[tuple[str, object]]) -> dict:
    """No duplicated authority fields anywhere in a private intake tree."""
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise IntakeError("Duplicate key in private acceptance manifest")
        obj[key] = value
    return obj


def outside_public_checkout(path: Path, *, purpose: str) -> Path:
    """Reject linked ancestors and evidence locations within public source."""
    _reject_private_path_chain(path, kind="Private acceptance")
    resolved = path.resolve(strict=True)
    if resolved.is_relative_to(ROOT.resolve()):
        raise IntakeError(f"Private acceptance {purpose} must reside outside the public checkout")
    _refuse_other_motionwright_worktrees(resolved)
    return resolved


def _reject_indirect_path_component(path: Path, *, kind: str) -> None:
    """Refuse symlinks and Windows NTFS junction/reparse links, including on 3.11.

    Path.is_symlink alone misses junctions on Windows Python 3.11. The
    FILE_ATTRIBUTE_REPARSE_POINT check also covers non-symlink reparse types.
    """
    if path.is_symlink():
        raise IntakeError(f"{kind} path traverses a symlink or reparse point")
    try:
        info = path.lstat()
        reparse_bit = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
        is_reparse = bool(getattr(info, "st_file_attributes", 0) & reparse_bit)
        is_junction = getattr(path, "is_junction", None)
        if is_reparse or (callable(is_junction) and is_junction()):
            raise IntakeError(f"{kind} path traverses a symlink or reparse point")
    except OSError as exc:
        raise IntakeError(f"{kind} path component is unavailable") from exc


def _reject_private_path_chain(path: Path, *, kind: str) -> None:
    """Refuse reparse ancestors even when only the final path is a real directory.

    Checking just the evidence root misses C:/private/junction/real-root
    where the middle directory is a junction pointing elsewhere.
    Deliberately refuse dot-dot path components before resolution.
    """
    absolute = path.absolute()
    current = Path(absolute.anchor)
    for part in absolute.parts[1:]:
        if part == "..":
            raise IntakeError(f"{kind} paths must not contain parent components")
        current = current / part
        _reject_indirect_path_component(current, kind=kind)


@lru_cache(maxsize=1)
def _motionwright_worktree_roots() -> tuple[Path, ...]:
    """Discover only worktrees attached to this Motionwright Git repository.

    Do not treat unrelated parent/user-home Git repositories as Motionwright
    worktrees: owner Downloads may legitimately be below such a repo.
    """
    try:
        result = subprocess.run(
            ["git", "-C", str(ROOT), "worktree", "list", "--porcelain"],
            capture_output=True, check=True, timeout=10,
        )
        roots = []
        # Git 2.34 on owner Windows does not support worktree list -z.
        # Porcelain paths occupy the remainder of a single "worktree " line.
        for field in result.stdout.splitlines():
            if not field.startswith(b"worktree "):
                continue
            raw = field[len(b"worktree "):]
            if not raw or len(raw) > 4096:
                raise IntakeError("Motionwright worktree paths are malformed")
            path = Path(os.fsdecode(raw))
            if not path.is_absolute():
                raise IntakeError("Motionwright worktree path is not absolute")
            roots.append(path.resolve(strict=False))
        if not roots or not any(ROOT.resolve().is_relative_to(root) for root in roots):
            raise IntakeError("Motionwright worktree authority could not be verified")
        return tuple(roots)
    except (OSError, subprocess.SubprocessError, UnicodeError) as exc:
        raise IntakeError("Motionwright worktree authority is unavailable") from exc


def _refuse_other_motionwright_worktrees(resolved: Path) -> None:
    """Do not create private receipts under ANY worktree of this repository."""
    if any(resolved.is_relative_to(root) for root in _motionwright_worktree_roots()):
        raise IntakeError("Private acceptance must be outside all Motionwright worktrees")


def _private_manifest_snapshot(path: Path) -> tuple[object, tuple[tuple[int, int, int, int, int], str]]:
    """Read an outside-checkout manifest via an identity-checked descriptor.

    Its identity and exact byte SHA can be rechecked after evidence hashing.
    This is a conservative best-effort filesystem snapshot, not an atomic
    transaction or a signature of the claimed independent reviewer.
    """
    outside_public_checkout(path.parent, purpose="manifest")
    _reject_indirect_path_component(path, kind="Manifest")
    try:
        before = path.stat()
        if not stat.S_ISREG(before.st_mode) or before.st_ino <= 0 or before.st_nlink != 1:
            raise IntakeError("Private acceptance manifest must be a single-linked identifiable regular file")
        size = before.st_size
        if not 0 < size <= MAX_MANIFEST_BYTES:
            raise IntakeError("Private acceptance manifest must be bounded and nonempty")
        identity = _file_fingerprint_identity(before)
        flags = (os.O_RDONLY | getattr(os, "O_BINARY", 0)
                 | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0))
        with os.fdopen(os.open(path, flags), "rb") as stream:
            opened = os.fstat(stream.fileno())
            if not stat.S_ISREG(opened.st_mode) or _file_fingerprint_identity(opened) != identity:
                raise IntakeError("Private acceptance manifest identity changed before reading")
            raw = stream.read(MAX_MANIFEST_BYTES + 1)
            after_read = os.fstat(stream.fileno())
            if _file_fingerprint_identity(after_read) != identity:
                raise IntakeError("Private acceptance manifest identity changed while reading")
        _reject_indirect_path_component(path, kind="Manifest")
        if _file_fingerprint_identity(path.stat()) != identity or len(raw) != size:
            raise IntakeError("Private acceptance manifest identity changed after reading")
    except OSError as exc:
        raise IntakeError("Private acceptance manifest is unavailable") from exc
    try:
        doc = json.loads(raw.decode("utf-8"), object_pairs_hook=_strict_json_object)
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise IntakeError("Private acceptance manifest is not valid UTF-8 JSON") from exc
    return doc, (identity, sha256(raw).hexdigest())


def load_private_manifest(path: Path) -> object:
    """Read a bounded, identity-checked private review file without replacing it."""
    return _private_manifest_snapshot(path)[0]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def valid_timestamp(value: object) -> bool:
    if not isinstance(value, str) or not value:
        return False
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return False
    return parsed.tzinfo is not None and parsed.utcoffset() == timedelta(0)


def canonical_ids() -> list[str]:
    doc = json.loads(CANONICAL.read_text(encoding="utf-8"))
    ids = [case.get("id") for case in doc.get("cases", [])]
    if ids != EXPECTED_IDS:
        raise IntakeError("Public acceptance ID list differs from the 60 canonical private-spec identifiers")
    return ids


def locked_semwright_revision() -> str:
    revision = json.loads(LOCK.read_text(encoding="utf-8"))["dependencies"]["semwright"]["revision"]
    if not isinstance(revision, str) or not SHA_RE.fullmatch(revision):
        raise IntakeError("Semwright lock lacks an exact 40-character Git revision")
    return revision


def checked_head() -> str:
    try:
        result = subprocess.run(
            ["git", "-C", str(ROOT), "rev-parse", "HEAD"],
            capture_output=True, text=True, check=True, timeout=10,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise IntakeError("Exact Motionwright Git checkout could not be verified") from exc
    revision = result.stdout.strip()
    if not SHA_RE.fullmatch(revision):
        raise IntakeError("Current Motionwright HEAD is not a concrete Git revision")
    return revision


def assert_clean_source_checkout() -> None:
    """Prevent a private acceptance source receipt for a dirty tracked tree."""
    try:
        check = subprocess.run(
            ["git", "-C", str(ROOT), "diff", "--quiet", "HEAD", "--"],
            capture_output=True, text=True, check=False, timeout=10,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise IntakeError("Tracked Git checkout could not be verified") from exc
    if check.returncode != 0:
        raise IntakeError("Cannot initialize intake from a dirty tracked checkout")


def checked_intake_source(requested: str | None) -> str:
    """Source-bound only to a matching, clean local Git checkout.

    This cannot attest a signed installed binary or authenticate the human
    execution/review identities later recorded in the private session.
    """
    actual = checked_head()
    if requested is not None and requested != actual:
        raise IntakeError("Acceptance source SHA differs from current Git checkout")
    assert_clean_source_checkout()
    return actual


def create_session(*, source_sha: str, executed_by: str = "") -> dict:
    if not SHA_RE.fullmatch(source_sha):
        raise IntakeError("source_sha must be the exact 40-character tested Motionwright commit")
    return {
        "schema_version": SCHEMA,
        "source": {
            "repository": "seradotcom/motionwright",
            "motionwright_sha": source_sha,
            "semwright_sha": locked_semwright_revision(),
            "private_spec_version": "0.1.0",
            "private_spec_text_embedded": False,
        },
        "session": {
            "id": str(uuid.uuid4()),
            "created_at_utc": utc_now(),
            "executed_by": executed_by.strip(),
            "notes": "",
        },
        "cases": [
            {
                "id": case_id,
                "status": "NOT_RUN",
                "executed_by": "",
                "reviewed_by": "",
                "independent": False,
                "executed_at_utc": None,
                "reviewed_at_utc": None,
                "notes": "",
                "evidence": [],
            }
            for case_id in canonical_ids()
        ],
    }


def validated_path(root: Path, relative: object) -> Path:
    outside_public_checkout(root, purpose="evidence root")
    if not isinstance(relative, str) or not relative or len(relative) > 1024:
        raise IntakeError("Evidence path must be a bounded relative POSIX path")
    normalized = PurePosixPath(relative)
    if normalized.is_absolute() or any(part in ("", ".", "..") for part in relative.split("/")):
        raise IntakeError("Evidence paths must not be absolute or contain parent/dot components")
    if "\\" in relative or normalized.parts[0].startswith("~"):
        raise IntakeError("Evidence paths must not use backslashes or home expansion")
    # Colon would name an NTFS alternate data stream or drive-relative path.
    # Treat evidence descriptors as portable paths on every platform.
    if ":" in relative:
        raise IntakeError("Evidence paths must not use Windows stream or drive syntax")
    _reject_indirect_path_component(root, kind="Evidence")
    current = root
    for part in normalized.parts:
        current = current / part
        _reject_indirect_path_component(current, kind="Evidence")
    resolved_root = root.resolve(strict=True)
    resolved = current.resolve(strict=True)
    if not resolved.is_relative_to(resolved_root) or not resolved.is_file():
        raise IntakeError(f"Evidence path is not a regular file within its root: {relative}")
    return resolved


def _file_fingerprint_identity(info: object) -> tuple[int, int, int, int, int]:
    """Private filesystem identity and mutation indicators, never exported.

    These checks are conservative observations, not an atomic filesystem
    transaction, attestation of installed product use, or proof of review.
    Filesystems without usable inode and hardlink metadata are refused.
    """
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_nlink)


def fingerprint(root: Path, relative: str) -> dict:
    path = validated_path(root, relative)
    try:
        before = path.stat()
        identity = _file_fingerprint_identity(before)
        if before.st_ino <= 0 or before.st_nlink != 1 or not stat.S_ISREG(before.st_mode):
            raise IntakeError("Evidence must be a single-linked identifiable regular file")
        size = before.st_size
        if not 0 < size <= MAX_EVIDENCE_BYTES:
            raise IntakeError("Evidence file is missing, empty or outside the 2 GiB individual budget")

        digest = sha256()
        actual = 0
        # Path validation occurs before open: check the opened descriptor too
        # so a swapped hardlink or symlink cannot be accepted based on its name.
        # O_NONBLOCK prevents a replaced FIFO from indefinitely blocking open.
        flags = (os.O_RDONLY | getattr(os, "O_BINARY", 0)
                 | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0))
        with os.fdopen(os.open(path, flags), "rb") as stream:
            opened = os.fstat(stream.fileno())
            if _file_fingerprint_identity(opened) != identity or not stat.S_ISREG(opened.st_mode):
                raise IntakeError("Evidence identity changed before hashing")
            while chunk := stream.read(1024 * 1024):
                actual += len(chunk)
                if actual > MAX_EVIDENCE_BYTES:
                    raise IntakeError("Evidence size changed beyond the 2 GiB budget during hashing")
                digest.update(chunk)
            after_read = os.fstat(stream.fileno())
            if _file_fingerprint_identity(after_read) != identity:
                raise IntakeError("Evidence identity changed while hashing")
        if _file_fingerprint_identity(path.stat()) != identity:
            raise IntakeError("Evidence identity changed after hashing")
        if actual != size:
            raise IntakeError("Evidence size changed during hashing")
        return {"path": relative, "sha256": digest.hexdigest(), "size_bytes": actual}
    except OSError as exc:
        raise IntakeError("Evidence identity or bytes unavailable") from exc


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise IntakeError(message)


def validate_session(doc: object, *, evidence_root: Path) -> dict[str, int]:
    _require(isinstance(doc, dict), "Session must be a JSON object")
    _require(doc.get("schema_version") == SCHEMA, "Unknown acceptance intake schema")
    source = doc.get("source")
    _require(isinstance(source, dict), "Missing source provenance")
    _require(source.get("repository") == "seradotcom/motionwright", "Unexpected source repository")
    _require(isinstance(source.get("motionwright_sha"), str) and
             SHA_RE.fullmatch(source["motionwright_sha"]) is not None,
             "Unpinned Motionwright source SHA")
    _require(source.get("semwright_sha") == locked_semwright_revision(),
             "Semwright source SHA does not match SOURCE_LOCK.json")
    _require(source.get("private_spec_version") == "0.1.0" and
             source.get("private_spec_text_embedded") is False,
             "Private acceptance specification must not be embedded in public review evidence")
    session = doc.get("session")
    _require(isinstance(session, dict), "Missing session metadata")
    _require(valid_timestamp(session.get("created_at_utc")), "Session creation time must include UTC offset")
    _require(isinstance(session.get("id"), str), "Session ID is missing")
    try:
        uuid.UUID(session["id"])
    except (ValueError, TypeError):
        raise IntakeError("Session ID is not a valid UUID") from None
    cases = doc.get("cases")
    _require(isinstance(cases, list) and len(cases) == 60
             and all(isinstance(case, dict) for case in cases)
             and [c.get("id") for c in cases] == canonical_ids(),
             "Session must contain each of the exact 60 canonical acceptance IDs, once and in order")
    root = outside_public_checkout(evidence_root, purpose="evidence root")
    _require(root.is_dir(), "Evidence root must be a real directory")
    counts: Counter[str] = Counter()
    evidence_paths: set[str] = set()
    for case in cases:
        case_id = case["id"]
        state = case.get("status")
        _require(isinstance(state, str) and state in STATES,
                 f"{case_id}: unknown acceptance status")
        counts[state] += 1
        items = case.get("evidence")
        _require(isinstance(items, list) and len(items) <= 32,
                 f"{case_id}: evidence must be a list with no more than 32 files")
        _require(isinstance(case.get("notes"), str), f"{case_id}: missing notes text")
        if state == "NOT_RUN":
            _require(
                not items and not case.get("independent")
                and not case.get("reviewed_by") and not case.get("executed_by")
                and case.get("executed_at_utc") is None
                and case.get("reviewed_at_utc") is None,
                f"{case_id}: NOT_RUN must not contain execution, review or evidence claims",
            )
            continue
        executor = case.get("executed_by")
        _require(isinstance(executor, str) and bool(executor.strip()),
                 f"{case_id}: executed test must name its operator")
        _require(valid_timestamp(case.get("executed_at_utc")),
                 f"{case_id}: execution time must include timezone")
        if state == "BLOCKED":
            _require(bool(case["notes"].strip()), f"{case_id}: blocking reason is required")
        else:
            _require(bool(items), f"{case_id}: PASS/FAIL requires at least one actual evidence file")
        if state == "PASS":
            _require(bool(case["notes"].strip()), f"{case_id}: PASS requires review rationale")
            reviewer = case.get("reviewed_by")
            _require(case.get("independent") is True and
                     isinstance(reviewer, str) and bool(reviewer.strip()) and
                     reviewer.strip().casefold() != executor.strip().casefold(),
                     f"{case_id}: PASS requires an independently identified reviewer different from the executor")
            _require(valid_timestamp(case.get("reviewed_at_utc")),
                     f"{case_id}: independent PASS review time is missing")
            executed_at = datetime.fromisoformat(case["executed_at_utc"].replace("Z", "+00:00"))
            reviewed_at = datetime.fromisoformat(case["reviewed_at_utc"].replace("Z", "+00:00"))
            _require(reviewed_at >= executed_at,
                     f"{case_id}: an independent review cannot precede test execution")
        for item in items:
            _require(isinstance(item, dict), f"{case_id}: invalid evidence record")
            path = item.get("path")
            digest = item.get("sha256")
            size = item.get("size_bytes")
            # Each privately reviewed scenario must carry its own evidence
            # namespace; an unrelated case's screenshot/receipt cannot be
            # silently counted as evidence for another case's independent PASS.
            _require(isinstance(path, str) and path.startswith(case_id + "/"),
                     f"{case_id}: evidence must be stored in its own case directory")
            _require(path not in evidence_paths,
                     f"{case_id}: duplicate evidence path in intake session")
            evidence_paths.add(path)
            _require(isinstance(digest, str) and DIGEST_RE.fullmatch(digest) is not None and
                     isinstance(size, int) and not isinstance(size, bool),
                     f"{case_id}: evidence requires exact digest and integer size")
            actual = fingerprint(root, path)
            _require(actual["sha256"] == digest and actual["size_bytes"] == size,
                     f"{case_id}: evidence has changed since it was recorded: {path}")
    return {status: counts[status] for status in ("NOT_RUN", "PASS", "FAIL", "BLOCKED")}


def verify_private_session(manifest: Path, *, evidence_root: Path) -> dict[str, int]:
    """Bind the final private review to this checkout before inspecting bytes.

    A different or dirty source tree cannot vouch for the installed build,
    even if the stored private JSON contains a syntactically valid SHA.
    This still cannot authenticate the external binary or reviewer identity.
    """
    doc, manifest_stamp = _private_manifest_snapshot(manifest)
    if not isinstance(doc, dict):
        raise IntakeError("Private acceptance session must be a JSON object")
    source = doc.get("source")
    if not isinstance(source, dict) or not isinstance(source.get("motionwright_sha"), str):
        raise IntakeError("Private acceptance session lacks exact source authority")
    source_sha = source["motionwright_sha"]
    checked_intake_source(source_sha)
    totals = validate_session(doc, evidence_root=evidence_root)
    # Evidence verification may hash many large private files. A checkout can
    # change during that time even if it was clean when verification began.
    # Do not emit a source-bound success until the SAME HEAD and tracked
    # inputs have been checked again after all evidence bytes were read.
    checked_intake_source(source_sha)
    _, after_manifest_stamp = _private_manifest_snapshot(manifest)
    if after_manifest_stamp != manifest_stamp:
        raise IntakeError("Private acceptance manifest changed during evidence verification")
    return totals


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    subs = parser.add_subparsers(dest="action", required=True)
    init = subs.add_parser("init", help="Create private NOT_RUN intake, never a PASS")
    init.add_argument("--output", required=True, type=Path)
    init.add_argument("--source-sha", default=None)
    init.add_argument("--executed-by", default="")
    verify = subs.add_parser("verify", help="Verify source, independent claims and evidence bytes")
    verify.add_argument("--manifest", required=True, type=Path)
    verify.add_argument("--evidence-root", required=True, type=Path)
    fp = subs.add_parser("fingerprint", help="Prepare one bounded evidence descriptor")
    fp.add_argument("--evidence-root", required=True, type=Path)
    fp.add_argument("--path", required=True)
    args = parser.parse_args()
    try:
        if args.action == "init":
            # Prevent accidentally committing private review sessions to a
            # public repository. Refuse replacing an existing session.
            # Resolve the *parent* to guard public-checkout paths hidden by
            # symlink aliases; the final file must not exist yet.
            output = outside_public_checkout(args.output.parent, purpose="manifest") / args.output.name
            if ":" in args.output.name:
                raise IntakeError("Private acceptance manifest name must not contain drive or stream syntax")
            data = create_session(
                source_sha=checked_intake_source(args.source_sha),
                executed_by=args.executed_by,
            )
            with output.open("x", encoding="utf-8") as file:
                json.dump(data, file, indent=2)
                file.write("\n")
            print(f"acceptance-intake=initialized cases=60 not_run=60 file={output}")
        elif args.action == "verify":
            totals = verify_private_session(
                args.manifest, evidence_root=args.evidence_root
            )
            print("acceptance-intake=verified " + " ".join(
                f"{key.lower()}={count}" for key, count in totals.items()
            ))
        else:
            print(json.dumps(fingerprint(args.evidence_root, args.path), sort_keys=True))
    except (IntakeError, OSError, ValueError) as exc:
        print(f"acceptance-intake: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
