use crate::ImportLimits;
use motionwright_domain::{DomainError, RationalTime};
use motionwright_storage::{Result, StorageError};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::{
    fs::{File, OpenOptions},
    io::{self, Read, Seek, SeekFrom, Write},
    path::Path,
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
};
use symphonia::{
    core::{
        codecs::audio::{AudioCodecParameters, AudioDecoderOptions},
        errors::Error as SymphoniaError,
        formats::{FormatOptions, Track, TrackType, probe::Hint},
        io::MediaSourceStream,
        meta::MetadataOptions,
    },
    default::{get_codecs, get_probe},
};

pub const WAVEFORM_PROXY_VERSION: u32 = 1;
pub const WAVEFORM_FRAMES_PER_PEAK: u32 = 2_048;
pub const MAX_WAVEFORM_PAGE_SIZE: usize = 2_048;
const WAVEFORM_MAGIC: &[u8; 8] = b"MWPEAK01";
const WAVEFORM_HEADER_BYTES: u64 = 72;

type AudioReader = Box<dyn symphonia::core::formats::FormatReader>;
type AudioDecoder = Box<dyn symphonia::core::codecs::audio::AudioDecoder>;
type OpenAudio = (AudioReader, AudioDecoder, u32);

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct AudioMeasurement {
    pub sample_rate_hz: u32,
    pub channels: u16,
    pub decoded_frames: u64,
    pub duration: RationalTime,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct WaveformProxySummary {
    pub source_sha256: String,
    pub sample_rate_hz: u32,
    pub channels: u16,
    pub frames_per_peak: u32,
    pub total_frames: u64,
    pub peak_count: u64,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct WaveformPage {
    pub schema: String,
    pub algorithm: String,
    pub source_sha256: String,
    pub sample_rate_hz: u32,
    pub channels: u16,
    pub frames_per_peak: u32,
    pub total_frames: u64,
    pub peak_count: u64,
    pub page_index: u64,
    pub page_size: usize,
    pub start_peak: u64,
    pub peaks: Vec<f32>,
    pub has_previous: bool,
    pub has_next: bool,
}

fn invalid(message: impl Into<String>) -> StorageError {
    DomainError::Invalid(message.into()).into()
}

fn invalid_proxy(message: impl Into<String>) -> StorageError {
    StorageError::InvalidDerivedCache(message.into())
}

fn open_audio(path: &Path) -> Result<OpenAudio> {
    let source = File::open(path)?;
    let stream = MediaSourceStream::new(Box::new(source), Default::default());
    let mut hint = Hint::new();
    if let Some(extension) = path.extension().and_then(|value| value.to_str()) {
        hint.with_extension(extension);
    }
    let format = get_probe()
        .probe(
            &hint,
            stream,
            FormatOptions::default(),
            MetadataOptions::default(),
        )
        .map_err(|error| invalid(format!("audio probe failed: {error}")))?;
    let track = format
        .default_track(TrackType::Audio)
        .ok_or_else(|| invalid("audio source contains no decodable audio track"))?;
    let track_id = track.id;
    let params = track
        .codec_params
        .as_ref()
        .and_then(|params| params.audio())
        .ok_or_else(|| invalid("audio codec parameters are unavailable"))?;
    let decoder = get_codecs()
        .make_audio_decoder(params, &AudioDecoderOptions::default())
        .map_err(|error| invalid(format!("audio decoder unavailable: {error}")))?;
    Ok((format, decoder, track_id))
}

fn validate_decoded_format(
    observed_rate: &mut Option<u32>,
    observed_channels: &mut Option<u16>,
    rate: u32,
    channels: u16,
) -> Result<()> {
    if !(8_000..=384_000).contains(&rate) || channels == 0 || channels > 32 {
        return Err(invalid("decoded audio format is outside supported bounds"));
    }
    if observed_rate.is_some_and(|value| value != rate)
        || observed_channels.is_some_and(|value| value != channels)
    {
        return Err(invalid(
            "audio format changes sample rate or channels mid-stream",
        ));
    }
    *observed_rate = Some(rate);
    *observed_channels = Some(channels);
    Ok(())
}

const AUDIO_READ_LIMIT_MESSAGE: &str = "audio measurement limit exceeded: audio_read_bytes";

fn audio_measurement_limit(name: &'static str) -> StorageError {
    invalid(format!("audio measurement limit exceeded: {name}"))
}

fn audio_read_limit_error() -> io::Error {
    io::Error::other(AUDIO_READ_LIMIT_MESSAGE)
}

fn check_audio_read_limit(exhausted: &AtomicBool) -> Result<()> {
    if exhausted.load(Ordering::Relaxed) {
        return Err(audio_measurement_limit("audio_read_bytes"));
    }
    Ok(())
}

/// Counts source reads across seeks; one extra byte distinguishes EOF from excess.
struct BoundedMeasurementFile<T = File> {
    file: T,
    byte_len: u64,
    remaining: u64,
    exhausted: Arc<AtomicBool>,
}

impl<T: Read> Read for BoundedMeasurementFile<T> {
    fn read(&mut self, buffer: &mut [u8]) -> io::Result<usize> {
        if buffer.is_empty() {
            return Ok(0);
        }
        if self.exhausted.load(Ordering::Relaxed) {
            return Err(audio_read_limit_error());
        }
        let allowed = usize::try_from(self.remaining.saturating_add(1))
            .unwrap_or(usize::MAX)
            .min(buffer.len());
        let read = self.file.read(&mut buffer[..allowed])?;
        let charged = u64::try_from(read).map_err(|_| {
            self.exhausted.store(true, Ordering::Relaxed);
            audio_read_limit_error()
        })?;
        if charged > self.remaining {
            self.remaining = 0;
            self.exhausted.store(true, Ordering::Relaxed);
            return Err(audio_read_limit_error());
        }
        self.remaining -= charged;
        Ok(read)
    }
}

impl<T: Seek> Seek for BoundedMeasurementFile<T> {
    fn seek(&mut self, position: SeekFrom) -> io::Result<u64> {
        if self.exhausted.load(Ordering::Relaxed) {
            return Err(audio_read_limit_error());
        }
        self.file.seek(position)
    }
}

impl<T: Read + Seek + Send + Sync> symphonia::core::io::MediaSource for BoundedMeasurementFile<T> {
    fn is_seekable(&self) -> bool {
        true
    }

    fn byte_len(&self) -> Option<u64> {
        Some(self.byte_len)
    }
}

fn validate_measurement_track(
    track: &Track,
    params: &AudioCodecParameters,
    limits: &ImportLimits,
) -> Result<()> {
    if params
        .sample_rate
        .is_some_and(|rate| !(8_000..=384_000).contains(&rate))
    {
        return Err(invalid(
            "declared audio sample rate is outside supported bounds",
        ));
    }
    let declared_channels = match params.channels.as_ref() {
        Some(channels) => {
            let count = u64::try_from(channels.count())
                .map_err(|_| invalid("declared audio channel count overflow"))?;
            if !(1..=32).contains(&count) {
                return Err(invalid(
                    "declared audio channel count is outside supported bounds",
                ));
            }
            Some(count)
        }
        None => None,
    };
    if let Some(extra_data) = params.extra_data.as_ref() {
        let bytes =
            u64::try_from(extra_data.len()).map_err(|_| audio_measurement_limit("packet_bytes"))?;
        if bytes > limits.packet_bytes() {
            return Err(audio_measurement_limit("packet_bytes"));
        }
    }

    // One channel is only a lower bound when the declared layout is unknown.
    let channels = declared_channels.unwrap_or(1);
    if let Some(frames) = params.max_frames_per_packet {
        let samples = frames
            .checked_mul(channels)
            .ok_or_else(|| audio_measurement_limit("packet_samples"))?;
        if samples > limits.packet_samples() {
            return Err(audio_measurement_limit("packet_samples"));
        }
    }
    if let Some(frames) = track.num_frames {
        let samples = frames
            .checked_mul(channels)
            .ok_or_else(|| audio_measurement_limit("decoded_samples"))?;
        if samples > limits.decoded_samples() {
            return Err(audio_measurement_limit("decoded_samples"));
        }
        if let Some(rate) = params.sample_rate
            && u128::from(frames) > u128::from(limits.audio_seconds()) * u128::from(rate)
        {
            return Err(audio_measurement_limit("audio_seconds"));
        }
    }
    // Stream duration uses its own rational time base, not sample frames.
    if let (Some(duration), Some(time_base)) = (track.duration, track.time_base) {
        let declared = u128::from(duration.get()) * u128::from(time_base.numer.get());
        let maximum = u128::from(limits.audio_seconds()) * u128::from(time_base.denom.get());
        if declared > maximum {
            return Err(audio_measurement_limit("audio_seconds"));
        }
    }
    Ok(())
}

/// Import-only opening preserves existing waveform and original-mix contracts.
fn open_measurement_audio(
    path: &Path,
    limits: &ImportLimits,
) -> Result<(OpenAudio, Arc<AtomicBool>)> {
    let source = File::open(path)?;
    let metadata = source.metadata()?;
    if !metadata.is_file() {
        return Err(invalid("audio measurement source must be a regular file"));
    }
    if metadata.len() > limits.source_bytes() {
        return Err(StorageError::BlobTooLarge {
            size: metadata.len(),
            limit: limits.source_bytes(),
        });
    }
    let exhausted = Arc::new(AtomicBool::new(false));
    let source = BoundedMeasurementFile {
        file: source,
        byte_len: metadata.len(),
        remaining: limits.audio_read_bytes(),
        exhausted: Arc::clone(&exhausted),
    };
    let stream = MediaSourceStream::new(Box::new(source), Default::default());
    let mut hint = Hint::new();
    if let Some(extension) = path.extension().and_then(|value| value.to_str()) {
        hint.with_extension(extension);
    }
    let probed = get_probe().probe(
        &hint,
        stream,
        FormatOptions::default(),
        MetadataOptions::default(),
    );
    // A probe may transform an IO error while trying other format candidates.
    check_audio_read_limit(&exhausted)?;
    let format = probed.map_err(|error| invalid(format!("audio probe failed: {error}")))?;
    let track = format
        .default_track(TrackType::Audio)
        .ok_or_else(|| invalid("audio source contains no decodable audio track"))?;
    let track_id = track.id;
    let params = track
        .codec_params
        .as_ref()
        .and_then(|params| params.audio())
        .ok_or_else(|| invalid("audio codec parameters are unavailable"))?;
    validate_measurement_track(track, params, limits)?;
    let decoder = get_codecs()
        .make_audio_decoder(params, &AudioDecoderOptions::default())
        .map_err(|error| invalid(format!("audio decoder unavailable: {error}")))?;
    Ok(((format, decoder, track_id), exhausted))
}

pub fn measure_audio_file(
    path: impl AsRef<Path>,
    limits: &ImportLimits,
) -> Result<AudioMeasurement> {
    let ((mut format, mut decoder, track_id), exhausted) =
        open_measurement_audio(path.as_ref(), limits)?;
    let mut demux_packets = 0_u64;
    let mut decoded_frames = 0_u64;
    let mut decoded_samples = 0_u64;
    let mut observed_rate = None;
    let mut observed_channels = None;
    loop {
        let next = format.next_packet();
        // Check on success, error and EOF: exhaustion cannot become truncation.
        check_audio_read_limit(&exhausted)?;
        let packet = match next {
            Ok(Some(packet)) => packet,
            Ok(None) => break,
            Err(SymphoniaError::ResetRequired) => {
                return Err(invalid(
                    "audio stream changed track layout during measurement",
                ));
            }
            Err(error) => return Err(invalid(format!("audio demux failed: {error}"))),
        };
        demux_packets = demux_packets
            .checked_add(1)
            .ok_or_else(|| audio_measurement_limit("demux_packets"))?;
        if demux_packets > limits.demux_packets() {
            return Err(audio_measurement_limit("demux_packets"));
        }
        let packet_bytes = u64::try_from(packet.data.len())
            .map_err(|_| audio_measurement_limit("packet_bytes"))?;
        if packet_bytes > limits.packet_bytes() {
            return Err(audio_measurement_limit("packet_bytes"));
        }
        // Discarding a track does not erase its demux work or encoded bytes.
        if packet.track_id != track_id {
            continue;
        }
        let decoded_result = decoder.decode(&packet);
        check_audio_read_limit(&exhausted)?;
        let decoded =
            decoded_result.map_err(|error| invalid(format!("audio decode failed: {error}")))?;
        let spec = decoded.spec();
        let rate = spec.rate();
        let channels = u16::try_from(spec.channels().count())
            .map_err(|_| invalid("audio channel count exceeds supported bounds"))?;
        validate_decoded_format(&mut observed_rate, &mut observed_channels, rate, channels)?;

        let frames =
            u64::try_from(decoded.frames()).map_err(|_| invalid("decoded frame count overflow"))?;
        let block_samples = frames
            .checked_mul(u64::from(channels))
            .ok_or_else(|| audio_measurement_limit("packet_samples"))?;
        if block_samples > limits.packet_samples() {
            return Err(audio_measurement_limit("packet_samples"));
        }
        let next_samples = decoded_samples
            .checked_add(block_samples)
            .ok_or_else(|| audio_measurement_limit("decoded_samples"))?;
        if next_samples > limits.decoded_samples() {
            return Err(audio_measurement_limit("decoded_samples"));
        }
        let next_frames = decoded_frames
            .checked_add(frames)
            .ok_or_else(|| invalid("decoded frame count overflow"))?;
        if u128::from(next_frames) > u128::from(limits.audio_seconds()) * u128::from(rate) {
            return Err(audio_measurement_limit("audio_seconds"));
        }
        decoded_samples = next_samples;
        decoded_frames = next_frames;
    }

    let sample_rate_hz = observed_rate.ok_or_else(|| invalid("audio decoded no frames"))?;
    let channels = observed_channels.ok_or_else(|| invalid("audio decoded no frames"))?;
    if decoded_frames == 0 {
        return Err(invalid("audio decoded no frames"));
    }
    let frames = i64::try_from(decoded_frames)
        .map_err(|_| invalid("audio duration exceeds rational-time bounds"))?;
    let duration = RationalTime::new(frames, i64::from(sample_rate_hz))
        .map_err(|error| invalid(format!("audio duration is invalid: {error}")))?;
    Ok(AudioMeasurement {
        sample_rate_hz,
        channels,
        decoded_frames,
        duration,
    })
}

pub fn waveform_fingerprint(source_sha256: &str, frames_per_peak: u32) -> Result<String> {
    let source = hex::decode(source_sha256)
        .map_err(|_| invalid("waveform source digest is not hexadecimal"))?;
    if source.len() != 32 || frames_per_peak == 0 {
        return Err(invalid("waveform fingerprint inputs are invalid"));
    }
    let mut hasher = Sha256::new();
    hasher.update(b"motionwright.waveform.sample-peak-max-abs");
    hasher.update(WAVEFORM_PROXY_VERSION.to_le_bytes());
    hasher.update(frames_per_peak.to_le_bytes());
    hasher.update(source);
    Ok(hex::encode(hasher.finalize()))
}

fn quantize_peak(value: f32) -> u16 {
    (value.clamp(0.0, 1.0) * f32::from(u16::MAX)).round() as u16
}

fn write_waveform_header(file: &mut File, summary: &WaveformProxySummary) -> Result<()> {
    let source = hex::decode(&summary.source_sha256)
        .map_err(|_| invalid_proxy("waveform proxy source digest is malformed"))?;
    if source.len() != 32 {
        return Err(invalid_proxy(
            "waveform proxy source digest has invalid length",
        ));
    }
    file.seek(SeekFrom::Start(0))?;
    file.write_all(WAVEFORM_MAGIC)?;
    file.write_all(&WAVEFORM_PROXY_VERSION.to_le_bytes())?;
    file.write_all(&summary.sample_rate_hz.to_le_bytes())?;
    file.write_all(&summary.channels.to_le_bytes())?;
    file.write_all(&0_u16.to_le_bytes())?;
    file.write_all(&summary.frames_per_peak.to_le_bytes())?;
    file.write_all(&summary.total_frames.to_le_bytes())?;
    file.write_all(&summary.peak_count.to_le_bytes())?;
    file.write_all(&source)?;
    Ok(())
}

fn read_u16(input: &mut File) -> Result<u16> {
    let mut bytes = [0_u8; 2];
    input.read_exact(&mut bytes)?;
    Ok(u16::from_le_bytes(bytes))
}

fn read_u32(input: &mut File) -> Result<u32> {
    let mut bytes = [0_u8; 4];
    input.read_exact(&mut bytes)?;
    Ok(u32::from_le_bytes(bytes))
}

fn read_u64(input: &mut File) -> Result<u64> {
    let mut bytes = [0_u8; 8];
    input.read_exact(&mut bytes)?;
    Ok(u64::from_le_bytes(bytes))
}

fn read_waveform_header(input: &mut File) -> Result<WaveformProxySummary> {
    input.seek(SeekFrom::Start(0))?;
    let mut magic = [0_u8; 8];
    input.read_exact(&mut magic)?;
    if &magic != WAVEFORM_MAGIC {
        return Err(invalid_proxy("waveform proxy magic is invalid"));
    }
    let version = read_u32(input)?;
    if version != WAVEFORM_PROXY_VERSION {
        return Err(invalid_proxy("waveform proxy version is unsupported"));
    }
    let sample_rate_hz = read_u32(input)?;
    let channels = read_u16(input)?;
    let reserved = read_u16(input)?;
    let frames_per_peak = read_u32(input)?;
    let total_frames = read_u64(input)?;
    let peak_count = read_u64(input)?;
    let mut source = [0_u8; 32];
    input.read_exact(&mut source)?;

    if reserved != 0
        || !(8_000..=384_000).contains(&sample_rate_hz)
        || channels == 0
        || channels > 32
        || frames_per_peak == 0
        || total_frames == 0
        || peak_count == 0
    {
        return Err(invalid_proxy("waveform proxy header is invalid"));
    }
    let expected_peaks = total_frames.div_ceil(u64::from(frames_per_peak));
    if peak_count != expected_peaks {
        return Err(invalid_proxy(
            "waveform proxy peak count does not match decoded frame count",
        ));
    }

    Ok(WaveformProxySummary {
        source_sha256: hex::encode(source),
        sample_rate_hz,
        channels,
        frames_per_peak,
        total_frames,
        peak_count,
    })
}

pub fn generate_waveform_proxy(
    source_path: impl AsRef<Path>,
    source_sha256: &str,
    destination: impl AsRef<Path>,
    frames_per_peak: u32,
) -> Result<WaveformProxySummary> {
    if frames_per_peak == 0 {
        return Err(invalid("waveform frames-per-peak must be positive"));
    }
    let source_digest = hex::decode(source_sha256)
        .map_err(|_| invalid("waveform source digest is not hexadecimal"))?;
    if source_digest.len() != 32 {
        return Err(invalid("waveform source digest length is invalid"));
    }

    let source_path = source_path.as_ref();
    let (mut format, mut decoder, track_id) = open_audio(source_path)?;
    let mut output = OpenOptions::new()
        .write(true)
        .read(true)
        .create_new(true)
        .open(destination)?;
    output.write_all(&[0_u8; WAVEFORM_HEADER_BYTES as usize])?;

    let mut total_frames = 0_u64;
    let mut peak_count = 0_u64;
    let mut window_frames = 0_u32;
    let mut window_peak = 0.0_f32;
    let mut observed_rate = None;
    let mut observed_channels = None;
    let mut samples = Vec::<f32>::new();

    loop {
        let packet = match format.next_packet() {
            Ok(Some(packet)) => packet,
            Ok(None) => break,
            Err(SymphoniaError::ResetRequired) => {
                return Err(invalid(
                    "audio stream changed track layout during waveform analysis",
                ));
            }
            Err(error) => return Err(invalid(format!("audio demux failed: {error}"))),
        };
        if packet.track_id != track_id {
            continue;
        }
        let decoded = decoder
            .decode(&packet)
            .map_err(|error| invalid(format!("audio decode failed: {error}")))?;
        let spec = decoded.spec();
        let rate = spec.rate();
        let channels = u16::try_from(spec.channels().count())
            .map_err(|_| invalid("audio channel count exceeds supported bounds"))?;
        validate_decoded_format(&mut observed_rate, &mut observed_channels, rate, channels)?;

        let channel_count = usize::from(channels);
        let sample_count = decoded.samples_interleaved();
        samples.resize(sample_count, 0.0);
        decoded.copy_to_slice_interleaved(&mut samples);
        if sample_count % channel_count != 0 {
            return Err(invalid("decoded interleaved audio has incomplete frames"));
        }

        for frame in samples[..sample_count].chunks_exact(channel_count) {
            let mut frame_peak = 0.0_f32;
            for sample in frame {
                if !sample.is_finite() {
                    return Err(invalid("decoded audio contains a non-finite sample"));
                }
                frame_peak = frame_peak.max(sample.abs());
            }
            window_peak = window_peak.max(frame_peak);
            window_frames += 1;
            total_frames = total_frames
                .checked_add(1)
                .ok_or_else(|| invalid("decoded frame count overflow"))?;
            if window_frames == frames_per_peak {
                output.write_all(&quantize_peak(window_peak).to_le_bytes())?;
                peak_count = peak_count
                    .checked_add(1)
                    .ok_or_else(|| invalid("waveform peak count overflow"))?;
                window_frames = 0;
                window_peak = 0.0;
            }
        }
    }

    if window_frames > 0 {
        output.write_all(&quantize_peak(window_peak).to_le_bytes())?;
        peak_count = peak_count
            .checked_add(1)
            .ok_or_else(|| invalid("waveform peak count overflow"))?;
    }

    let sample_rate_hz = observed_rate.ok_or_else(|| invalid("audio decoded no frames"))?;
    let channels = observed_channels.ok_or_else(|| invalid("audio decoded no frames"))?;
    if total_frames == 0 || peak_count == 0 {
        return Err(invalid("audio decoded no frames"));
    }
    let summary = WaveformProxySummary {
        source_sha256: source_sha256.to_ascii_lowercase(),
        sample_rate_hz,
        channels,
        frames_per_peak,
        total_frames,
        peak_count,
    };
    write_waveform_header(&mut output, &summary)?;
    output.flush()?;
    output.sync_all()?;
    Ok(summary)
}

pub fn read_waveform_page(
    proxy_path: impl AsRef<Path>,
    expected_source_sha256: &str,
    expected_sample_rate_hz: u32,
    expected_channels: u16,
    page_index: u64,
    page_size: usize,
) -> Result<WaveformPage> {
    if page_size == 0 || page_size > MAX_WAVEFORM_PAGE_SIZE {
        return Err(invalid("waveform page size is out of bounds"));
    }
    let mut input = File::open(proxy_path)?;
    let summary = read_waveform_header(&mut input)?;
    if !summary
        .source_sha256
        .eq_ignore_ascii_case(expected_source_sha256)
        || summary.sample_rate_hz != expected_sample_rate_hz
        || summary.channels != expected_channels
        || summary.frames_per_peak != WAVEFORM_FRAMES_PER_PEAK
    {
        return Err(invalid_proxy(
            "waveform proxy identity does not match the selected voice track",
        ));
    }

    let expected_len = WAVEFORM_HEADER_BYTES
        .checked_add(
            summary
                .peak_count
                .checked_mul(2)
                .ok_or_else(|| invalid_proxy("waveform proxy byte length overflow"))?,
        )
        .ok_or_else(|| invalid_proxy("waveform proxy byte length overflow"))?;
    if input.metadata()?.len() != expected_len {
        return Err(invalid_proxy(
            "waveform proxy byte length does not match its header",
        ));
    }

    let page_size_u64 =
        u64::try_from(page_size).map_err(|_| invalid("waveform page size is invalid"))?;
    let start_peak = page_index
        .checked_mul(page_size_u64)
        .ok_or_else(|| invalid("waveform page offset overflow"))?;
    if start_peak >= summary.peak_count && page_index != 0 {
        return Err(invalid("waveform page is outside the available proxy"));
    }
    let remaining = summary.peak_count.saturating_sub(start_peak);
    let count = remaining.min(page_size_u64);
    let offset = WAVEFORM_HEADER_BYTES
        .checked_add(
            start_peak
                .checked_mul(2)
                .ok_or_else(|| invalid("waveform page offset overflow"))?,
        )
        .ok_or_else(|| invalid("waveform page offset overflow"))?;
    input.seek(SeekFrom::Start(offset))?;

    let mut peaks = Vec::with_capacity(usize::try_from(count).unwrap_or(page_size));
    for _ in 0..count {
        peaks.push(f32::from(read_u16(&mut input)?) / f32::from(u16::MAX));
    }

    Ok(WaveformPage {
        schema: "motionwright.waveform-page.v1".into(),
        algorithm: "sample-peak-max-abs-v1".into(),
        source_sha256: summary.source_sha256,
        sample_rate_hz: summary.sample_rate_hz,
        channels: summary.channels,
        frames_per_peak: summary.frames_per_peak,
        total_frames: summary.total_frames,
        peak_count: summary.peak_count,
        page_index,
        page_size,
        start_peak,
        peaks,
        has_previous: page_index > 0,
        has_next: start_peak.saturating_add(count) < summary.peak_count,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    fn write_pcm16_wav(path: &Path, sample_rate: u32, channels: u16, samples: &[i16]) {
        assert_eq!(samples.len() % usize::from(channels), 0);
        let data_bytes = u32::try_from(samples.len() * 2).unwrap();
        let mut file = File::create(path).unwrap();
        file.write_all(b"RIFF").unwrap();
        file.write_all(&(36 + data_bytes).to_le_bytes()).unwrap();
        file.write_all(b"WAVEfmt ").unwrap();
        file.write_all(&16_u32.to_le_bytes()).unwrap();
        file.write_all(&1_u16.to_le_bytes()).unwrap();
        file.write_all(&channels.to_le_bytes()).unwrap();
        file.write_all(&sample_rate.to_le_bytes()).unwrap();
        file.write_all(&(sample_rate * u32::from(channels) * 2).to_le_bytes())
            .unwrap();
        file.write_all(&(channels * 2).to_le_bytes()).unwrap();
        file.write_all(&16_u16.to_le_bytes()).unwrap();
        file.write_all(b"data").unwrap();
        file.write_all(&data_bytes.to_le_bytes()).unwrap();
        for sample in samples {
            file.write_all(&sample.to_le_bytes()).unwrap();
        }
        file.sync_all().unwrap();
    }

    #[test]
    fn measures_decoded_frames_instead_of_guessing_from_file_size() {
        let temp = tempfile::tempdir().unwrap();
        let path = temp.path().join("voice.wav");
        let samples = vec![0_i16; 72_000];
        write_pcm16_wav(&path, 48_000, 1, &samples);
        let measured = measure_audio_file(&path, &ImportLimits::default()).unwrap();
        assert_eq!(measured.sample_rate_hz, 48_000);
        assert_eq!(measured.channels, 1);
        assert_eq!(measured.decoded_frames, 72_000);
        assert_eq!(measured.duration, RationalTime::new(3, 2).unwrap());
    }

    #[test]
    fn waveform_proxy_is_paged_and_bound_to_source_measurements() {
        let temp = tempfile::tempdir().unwrap();
        let source = temp.path().join("voice.wav");
        let mut samples = vec![0_i16; 5_000];
        samples[100] = i16::MAX;
        samples[2_100] = i16::MAX / 2;
        samples[4_500] = i16::MAX / 4;
        write_pcm16_wav(&source, 8_000, 1, &samples);

        let source_sha256 = {
            let bytes = std::fs::read(&source).unwrap();
            hex::encode(Sha256::digest(bytes))
        };
        let proxy = temp.path().join("voice.mwpeak");
        let summary =
            generate_waveform_proxy(&source, &source_sha256, &proxy, WAVEFORM_FRAMES_PER_PEAK)
                .unwrap();
        assert_eq!(summary.total_frames, 5_000);
        assert_eq!(summary.peak_count, 3);

        let first = read_waveform_page(&proxy, &source_sha256, 8_000, 1, 0, 2).unwrap();
        assert_eq!(first.peaks.len(), 2);
        assert!(first.peaks[0] > 0.99);
        assert!((0.49..0.51).contains(&first.peaks[1]));
        assert!(first.has_next);
        assert!(!first.has_previous);

        let second = read_waveform_page(&proxy, &source_sha256, 8_000, 1, 1, 2).unwrap();
        assert_eq!(second.peaks.len(), 1);
        assert!((0.24..0.26).contains(&second.peaks[0]));
        assert!(second.has_previous);
        assert!(!second.has_next);
    }

    #[test]
    fn waveform_proxy_rejects_track_identity_mismatch() {
        let temp = tempfile::tempdir().unwrap();
        let source = temp.path().join("voice.wav");
        write_pcm16_wav(&source, 8_000, 1, &vec![0_i16; 4_096]);
        let source_sha256 = {
            let bytes = std::fs::read(&source).unwrap();
            hex::encode(Sha256::digest(bytes))
        };
        let proxy = temp.path().join("voice.mwpeak");
        generate_waveform_proxy(&source, &source_sha256, &proxy, WAVEFORM_FRAMES_PER_PEAK).unwrap();

        let error = read_waveform_page(&proxy, &source_sha256, 48_000, 1, 0, 32).unwrap_err();
        assert!(matches!(error, StorageError::InvalidDerivedCache(_)));
    }
}

#[cfg(test)]
pub(super) type OriginalMixPhaseHook = Box<dyn FnOnce()>;
#[cfg(test)]
std::thread_local! {
    pub(super) static BEFORE_ORIGINAL_MIX_DECODE: std::cell::RefCell<Option<OriginalMixPhaseHook>> =
        const { std::cell::RefCell::new(None) };
    pub(super) static BEFORE_ORIGINAL_MIX_RECHECK: std::cell::RefCell<Option<OriginalMixPhaseHook>> =
        const { std::cell::RefCell::new(None) };
}
#[cfg(test)]
pub(super) fn run_original_mix_decode_hook() {
    let hook = BEFORE_ORIGINAL_MIX_DECODE.with(|slot| slot.borrow_mut().take());
    if let Some(hook) = hook {
        hook();
    }
}
#[cfg(test)]
pub(super) fn run_original_mix_recheck_hook() {
    let hook = BEFORE_ORIGINAL_MIX_RECHECK.with(|slot| slot.borrow_mut().take());
    if let Some(hook) = hook {
        hook();
    }
}

/// Exact PCM source bytes for first-party original MixPlan.
/// Read only after Storage verified a project-owned, content-addressed blob.
/// Does not resample, infer speech, normalize, or publish a rendered file.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OriginalMixDecodedPcm {
    pub original_asset_sha256: String,
    pub decoded_pcm_sha256: String,
    pub sample_frames: u64,
    pub interleaved_s16le: Vec<u8>,
}
/// Closed native decode policies. The existing audition API always selects
/// Audition15Seconds; a full-cut caller must provide the complete RevisionStamp.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum OriginalMixDecodeBudget {
    Audition15Seconds,
    FullCut180Seconds,
}

impl OriginalMixDecodeBudget {
    pub(crate) const fn source_bytes(self) -> u64 {
        match self {
            Self::Audition15Seconds => 8 * 1024 * 1024,
            Self::FullCut180Seconds => 64 * 1024 * 1024,
        }
    }

    const fn seconds(self) -> u64 {
        match self {
            Self::Audition15Seconds => 15,
            Self::FullCut180Seconds => 180,
        }
    }

    const fn sample_frames(self) -> u64 {
        48_000 * self.seconds()
    }

    const fn channel_samples(self) -> u64 {
        2 * self.sample_frames()
    }
}

const ORIGINAL_MIX_PACKET_BYTES: u64 = 16 * 1024 * 1024;
const ORIGINAL_MIX_BLOCK_SAMPLES: u64 = 1_048_576;
const ORIGINAL_MIX_DEMUX_PACKETS: u64 = 1_000_000;
const ORIGINAL_MIX_READ_BYTES: u64 = 256 * 1024 * 1024;

fn original_mix_limit(name: &'static str) -> StorageError {
    invalid(format!("Original mix decode limit exceeded: {name}"))
}

fn check_original_mix_read_limit(exhausted: &AtomicBool) -> Result<()> {
    if exhausted.load(Ordering::Relaxed) {
        return Err(original_mix_limit("audio_read_bytes"));
    }
    Ok(())
}

fn validate_original_mix_track(
    track: &Track,
    params: &AudioCodecParameters,
    budget: OriginalMixDecodeBudget,
) -> Result<()> {
    if params.sample_rate.is_some_and(|rate| rate != 48_000)
        || params
            .channels
            .as_ref()
            .is_some_and(|channels| channels.count() != 2)
    {
        return Err(invalid(
            "Original mix accepts only measured 48-kHz stereo audio: explicit resampling is a separate owner decision",
        ));
    }
    if let Some(extra_data) = params.extra_data.as_ref() {
        let bytes =
            u64::try_from(extra_data.len()).map_err(|_| original_mix_limit("packet_bytes"))?;
        if bytes > ORIGINAL_MIX_PACKET_BYTES {
            return Err(original_mix_limit("packet_bytes"));
        }
    }
    if let Some(frames) = params.max_frames_per_packet {
        let samples = frames
            .checked_mul(2)
            .ok_or_else(|| original_mix_limit("block_samples"))?;
        if samples > ORIGINAL_MIX_BLOCK_SAMPLES {
            return Err(original_mix_limit("block_samples"));
        }
    }
    if track
        .num_frames
        .is_some_and(|frames| frames > budget.sample_frames())
    {
        return Err(original_mix_limit("sample_frames"));
    }
    if let (Some(duration), Some(time_base)) = (track.duration, track.time_base) {
        let declared = u128::from(duration.get()) * u128::from(time_base.numer.get());
        let maximum = u128::from(budget.seconds()) * u128::from(time_base.denom.get());
        if declared > maximum {
            return Err(original_mix_limit("sample_frames"));
        }
    }
    Ok(())
}

/// Decode the same verified container bytes captured by Storage. No source
/// pathname is reopened by the decoder, and no full container clone is made.
/// Individual codec calls are not a wall-clock or decoder-internal RAM bound.
pub(crate) fn decode_original_mix_pcm_bytes(
    bytes: Vec<u8>,
    original_asset_sha256: &str,
    budget: OriginalMixDecodeBudget,
) -> Result<OriginalMixDecodedPcm> {
    let byte_len = u64::try_from(bytes.len()).map_err(|_| original_mix_limit("source_bytes"))?;
    if !(44..=budget.source_bytes()).contains(&byte_len) {
        return Err(original_mix_limit("source_bytes"));
    }
    if hex::encode(Sha256::digest(&bytes)) != original_asset_sha256 {
        return Err(invalid(
            "Original source asset fingerprint differs from captured decode bytes",
        ));
    }

    let exhausted = Arc::new(AtomicBool::new(false));
    let source = BoundedMeasurementFile {
        file: std::io::Cursor::new(bytes),
        byte_len,
        remaining: ORIGINAL_MIX_READ_BYTES,
        exhausted: Arc::clone(&exhausted),
    };
    let stream = MediaSourceStream::new(Box::new(source), Default::default());
    let mut hint = Hint::new();
    hint.with_extension("wav");
    let probed = get_probe().probe(
        &hint,
        stream,
        FormatOptions::default(),
        MetadataOptions::default(),
    );
    check_original_mix_read_limit(&exhausted)?;
    let mut format =
        probed.map_err(|error| invalid(format!("Original mix audio probe failed: {error}")))?;
    let track = format
        .default_track(TrackType::Audio)
        .ok_or_else(|| invalid("Original mix source contains no decodable audio track"))?;
    let track_id = track.id;
    let params = track
        .codec_params
        .as_ref()
        .and_then(|params| params.audio())
        .ok_or_else(|| invalid("Original mix audio codec parameters are unavailable"))?;
    validate_original_mix_track(track, params, budget)?;
    let mut decoder = get_codecs()
        .make_audio_decoder(params, &AudioDecoderOptions::default())
        .map_err(|error| invalid(format!("Original mix audio decoder unavailable: {error}")))?;

    let maximum_output_bytes = budget
        .sample_frames()
        .checked_mul(4)
        .and_then(|count| usize::try_from(count).ok())
        .ok_or_else(|| original_mix_limit("output_bytes"))?;
    let mut raw = Vec::new();
    let mut frames = 0_u64;
    let mut samples = 0_u64;
    let mut demux_packets = 0_u64;
    loop {
        let next = format.next_packet();
        // A swallowed read-limit error must not turn into a successful EOF.
        check_original_mix_read_limit(&exhausted)?;
        let packet = match next {
            Ok(Some(packet)) => packet,
            Ok(None) => break,
            Err(SymphoniaError::ResetRequired) => {
                return Err(invalid(
                    "Mixed audio track cannot change source format mid-decode",
                ));
            }
            Err(error) => {
                return Err(invalid(format!(
                    "Original mix decode packet invalid: {error}"
                )));
            }
        };
        demux_packets = demux_packets
            .checked_add(1)
            .ok_or_else(|| original_mix_limit("demux_packets"))?;
        if demux_packets > ORIGINAL_MIX_DEMUX_PACKETS {
            return Err(original_mix_limit("demux_packets"));
        }
        let packet_bytes =
            u64::try_from(packet.data.len()).map_err(|_| original_mix_limit("packet_bytes"))?;
        if packet_bytes > ORIGINAL_MIX_PACKET_BYTES {
            return Err(original_mix_limit("packet_bytes"));
        }
        // Every track consumes the finite demux and packet budgets.
        if packet.track_id != track_id {
            continue;
        }
        let decoded_result = decoder.decode(&packet);
        check_original_mix_read_limit(&exhausted)?;
        let decoded = decoded_result
            .map_err(|error| invalid(format!("Original mix audio decode failed: {error}")))?;
        if decoded.spec().rate() != 48_000 || decoded.spec().channels().count() != 2 {
            return Err(invalid(
                "Original mix accepts only measured 48-kHz stereo audio: explicit resampling is a separate owner decision",
            ));
        }
        let block_frames =
            u64::try_from(decoded.frames()).map_err(|_| original_mix_limit("sample_frames"))?;
        let block_samples = block_frames
            .checked_mul(2)
            .ok_or_else(|| original_mix_limit("block_samples"))?;
        if block_samples > ORIGINAL_MIX_BLOCK_SAMPLES {
            return Err(original_mix_limit("block_samples"));
        }
        let block_len =
            usize::try_from(block_samples).map_err(|_| original_mix_limit("block_samples"))?;
        if decoded.samples_interleaved() != block_len {
            return Err(invalid("Original mix decoded an incomplete stereo frame"));
        }
        let next_frames = frames
            .checked_add(block_frames)
            .ok_or_else(|| original_mix_limit("sample_frames"))?;
        if next_frames > budget.sample_frames() {
            return Err(original_mix_limit("sample_frames"));
        }
        let next_samples = samples
            .checked_add(block_samples)
            .ok_or_else(|| original_mix_limit("channel_samples"))?;
        if next_samples > budget.channel_samples() {
            return Err(original_mix_limit("channel_samples"));
        }
        let extra_bytes = block_len
            .checked_mul(2)
            .ok_or_else(|| original_mix_limit("output_bytes"))?;
        let expected_bytes = next_frames
            .checked_mul(4)
            .and_then(|count| usize::try_from(count).ok())
            .ok_or_else(|| original_mix_limit("output_bytes"))?;
        if raw.len().checked_add(extra_bytes) != Some(expected_bytes) {
            return Err(invalid("Original mix PCM byte count is inconsistent"));
        }
        // All block and cumulative bounds precede Motionwright output buffers.
        let mut values = Vec::new();
        values
            .try_reserve_exact(block_len)
            .map_err(|_| original_mix_limit("block_allocation"))?;
        if expected_bytes > raw.capacity() {
            let capacity = expected_bytes
                .max(raw.capacity().saturating_mul(2))
                .min(maximum_output_bytes);
            raw.try_reserve_exact(capacity - raw.len())
                .map_err(|_| original_mix_limit("output_allocation"))?;
        }
        values.resize(block_len, 0_f32);
        decoded.copy_to_slice_interleaved(&mut values);
        for value in values {
            if !value.is_finite() || !(-1.0..=1.0).contains(&value) {
                return Err(invalid(
                    "Original mixed source has nonfinite or invalid audio sample",
                ));
            }
            let quantized = (value * 32768.0).round().clamp(-32768.0, 32767.0) as i16;
            raw.extend_from_slice(&quantized.to_le_bytes());
        }
        frames = next_frames;
        samples = next_samples;
    }
    if frames < 48_000
        || u64::try_from(raw.len()).ok() != frames.checked_mul(4)
        || samples != frames * 2
    {
        return Err(invalid(
            "Original mix requires at least one second of complete stereo samples within the selected budget",
        ));
    }
    Ok(OriginalMixDecodedPcm {
        original_asset_sha256: original_asset_sha256.into(),
        decoded_pcm_sha256: hex::encode(Sha256::digest(&raw)),
        sample_frames: frames,
        interleaved_s16le: raw,
    })
}

#[cfg(test)]
mod original_mix_source_tests {
    use super::*;

    // Preserve the original assertions through actual Storage capture and the
    // canonical buffer decoder. The symlink case exercises the retained import
    // opener; the Service integration cases cover a replaced CAS leaf.
    fn decode_original_mix_pcm(
        owner_path: &Path,
        original_asset_sha256: &str,
    ) -> Result<OriginalMixDecodedPcm> {
        let temp = tempfile::tempdir()?;
        let store = motionwright_storage::Store::open(temp.path().join("audio-fixture.sqlite3"))?;
        let budget = OriginalMixDecodeBudget::Audition15Seconds;
        let staged = store.stage_file_import_with_limit(owner_path, budget.source_bytes())?;
        let descriptor = store.publish_file_import(&staged)?;
        let bytes = store.read_blob(&descriptor.sha256, budget.source_bytes())?;
        decode_original_mix_pcm_bytes(bytes, original_asset_sha256, budget)
    }
    fn wav(rate: u32, channels: u16, frames: usize) -> (Vec<u8>, Vec<u8>) {
        let mut source = Vec::new();
        for sample in 0..frames {
            let value = if sample % 2 == 0 { 4500_i16 } else { -4500_i16 };
            for _ in 0..channels {
                source.extend_from_slice(&value.to_le_bytes());
            }
        }
        let bytes = source.len() as u32;
        let mut wav = Vec::new();
        wav.extend_from_slice(b"RIFF");
        wav.extend_from_slice(&(36 + bytes).to_le_bytes());
        wav.extend_from_slice(b"WAVEfmt ");
        wav.extend_from_slice(&16_u32.to_le_bytes());
        wav.extend_from_slice(&1_u16.to_le_bytes());
        wav.extend_from_slice(&channels.to_le_bytes());
        wav.extend_from_slice(&rate.to_le_bytes());
        wav.extend_from_slice(&(rate * u32::from(channels) * 2).to_le_bytes());
        wav.extend_from_slice(&(channels * 2).to_le_bytes());
        wav.extend_from_slice(&16_u16.to_le_bytes());
        wav.extend_from_slice(b"data");
        wav.extend_from_slice(&bytes.to_le_bytes());
        wav.extend_from_slice(&source);
        (wav, source)
    }
    #[test]
    fn imported_original_wav_and_its_pcm_keep_distinct_checked_sha256() {
        let temp = tempfile::tempdir().unwrap();
        let file = temp.path().join("original-voice.wav");
        let (wav, source) = wav(48000, 2, 48000);
        std::fs::write(&file, &wav).unwrap();
        let container_sha = hex::encode(Sha256::digest(&wav));
        let parsed = decode_original_mix_pcm(&file, &container_sha).unwrap();
        assert_eq!(parsed.sample_frames, 48000);
        assert_eq!(parsed.interleaved_s16le, source);
        assert_eq!(parsed.original_asset_sha256, container_sha);
        assert_eq!(
            parsed.decoded_pcm_sha256,
            hex::encode(Sha256::digest(&source))
        );
        assert_ne!(parsed.original_asset_sha256, parsed.decoded_pcm_sha256);
    }
    #[test]
    fn stale_sha_or_unsupported_rate_and_channels_never_pass_pcm_decoder() {
        let temp = tempfile::tempdir().unwrap();
        let file = temp.path().join("invalid.wav");
        let (original_wav, _) = wav(48000, 2, 48000);
        std::fs::write(&file, &original_wav).unwrap();
        assert!(decode_original_mix_pcm(&file, &"ab".repeat(32)).is_err());
        let (audio, _) = wav(44100, 2, 44100);
        std::fs::write(&file, &audio).unwrap();
        assert!(decode_original_mix_pcm(&file, &hex::encode(Sha256::digest(&audio))).is_err());
        let (audio, _) = wav(48000, 1, 48000);
        std::fs::write(&file, &audio).unwrap();
        assert!(decode_original_mix_pcm(&file, &hex::encode(Sha256::digest(&audio))).is_err());
    }
    #[cfg(unix)]
    #[test]
    fn symlink_to_owner_audio_is_not_a_source_grant() {
        let temp = tempfile::tempdir().unwrap();
        let original = temp.path().join("voice.wav");
        let linked = temp.path().join("shortcut.wav");
        let (wav, _) = wav(48000, 2, 48000);
        std::fs::write(&original, &wav).unwrap();
        std::os::unix::fs::symlink(&original, &linked).unwrap();
        assert!(decode_original_mix_pcm(&linked, &hex::encode(Sha256::digest(&wav))).is_err());
    }
}

#[cfg(test)]
mod measurement_budget_tests {
    use super::*;

    fn reader(path: &Path, limit: u64) -> BoundedMeasurementFile {
        let file = File::open(path).unwrap();
        BoundedMeasurementFile {
            byte_len: file.metadata().unwrap().len(),
            file,
            remaining: limit,
            exhausted: Arc::new(AtomicBool::new(false)),
        }
    }

    #[test]
    fn bounded_file_accepts_exact_budget_and_true_eof() {
        let temp = tempfile::tempdir().unwrap();
        let path = temp.path().join("exact.bin");
        std::fs::write(&path, b"abcd").unwrap();
        let mut source = reader(&path, 4);
        let mut captured = Vec::new();
        source.read_to_end(&mut captured).unwrap();
        assert_eq!(captured, b"abcd");
        let mut byte = [0_u8];
        assert_eq!(source.read(&mut byte).unwrap(), 0);
        assert_eq!(source.read(&mut byte).unwrap(), 0);
        assert_eq!(source.remaining, 0);
        assert!(!source.exhausted.load(Ordering::Relaxed));
        assert_eq!(source.file.stream_position().unwrap(), 4);
    }

    #[test]
    fn bounded_file_seek_charges_rereads_and_keeps_exhaustion() {
        let temp = tempfile::tempdir().unwrap();
        let path = temp.path().join("seek.bin");
        std::fs::write(&path, b"abcdef").unwrap();
        let mut source = reader(&path, 4);
        let mut pair = [0_u8; 2];
        source.read_exact(&mut pair).unwrap();
        assert_eq!(&pair, b"ab");
        source.seek(SeekFrom::Start(0)).unwrap();
        source.read_exact(&mut pair).unwrap();
        assert_eq!(&pair, b"ab");
        assert_eq!(source.remaining, 0);
        assert!(source.read(&mut pair).is_err());
        assert_eq!(source.file.stream_position().unwrap(), 3);
        assert!(source.exhausted.load(Ordering::Relaxed));
        assert!(source.seek(SeekFrom::Start(0)).is_err());
        assert!(source.read(&mut pair).is_err());
        assert_eq!(source.file.stream_position().unwrap(), 3);
        assert_eq!(source.remaining, 0);
    }

    #[test]
    fn bounded_file_consumes_only_one_excess_probe_byte() {
        let temp = tempfile::tempdir().unwrap();
        let path = temp.path().join("excess.bin");
        std::fs::write(&path, [7_u8; 32]).unwrap();
        let mut source = reader(&path, 4);
        assert!(source.read_to_end(&mut Vec::new()).is_err());
        assert_eq!(source.file.stream_position().unwrap(), 5);
        assert_eq!(source.remaining, 0);
        assert!(source.exhausted.load(Ordering::Relaxed));
        for _ in 0..3 {
            assert!(source.read(&mut [0_u8; 8]).is_err());
            assert_eq!(source.file.stream_position().unwrap(), 5);
        }
        assert_eq!(source.read(&mut []).unwrap(), 0);
        assert!(source.exhausted.load(Ordering::Relaxed));
        assert_eq!(source.file.stream_position().unwrap(), 5);
    }
}
