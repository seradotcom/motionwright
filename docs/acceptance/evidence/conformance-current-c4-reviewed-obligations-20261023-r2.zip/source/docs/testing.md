# Testing strategy

The test pyramid separates evidence rather than counting raw test totals.

1. **Domain/schema** — closed parsing, IDs/revisions, canonical Semwright rational time, locks, canvas relations/property locks, creative proposal budgets, change validation, serialization and migrations.
2. **Storage/service** — transactional CAS, request deduplication, wrong-base rejection, crash/reopen, concurrent writers, event replay, future-schema rejection, keyset pagination, backup digest verification, dry-run import, restore generation rotation without receipt resurrection, immutable content-addressed blob admission, bounded digest-verified reads, portable bundle round-trip and tamper rejection.
3. **Integrated UI** — keyboard/pointer editing, shared revision updates, semantic Canvas transforms, stored alternative selection, stale/conflict states, offline/error recovery and accessibility.
4. **Native E2E** — external client → Semwright Core/Host/Native SDK → Motionwright → persisted state, including observation scopes and bounded creative commands.
5. **Render E2E** — project intent → Semwright renderer capabilities → artifact → readback → Effects/Graph.
6. **Production** — multiple projects, variants, export/reimport and revision-ten maintenance benchmark.

## Local versus CI

The workstation is kept light. Source-policy checks, formatting and other non-building checks may run locally. Dependency installation, Rust compilation/tests/clippy, browser installation and Playwright, Tauri builds, renderer work, coverage, audit, fuzzing and large fixtures belong in GitHub Actions.

Current required CI lanes are:

- `source-policy`;
- Rust core + Native SDK consumer tests and clippy;
- Studio unit/type/build;
- Chromium browser acceptance;
- Linux desktop shell check;
- immutable Semwright Native SDK pin verification;
- security/delivery policy, controlled-import contracts and exact-source delivery-manifest evidence.

The heavier workflow separately owns coverage/security and release-shaped builds. Renderer/Graph/Effects lanes are added only when they execute real integrations; a placeholder is never reported as acceptance evidence.

GitHub Actions receipts must identify app SHA, Semwright pin, suite, environment and input fixtures. A skipped, cancelled or unavailable gate is not a PASS.
## Canonical evidence lane

The `Canonical Graph and Effects` workflow is exact-SHA evidence for adapter compatibility. It runs Semwright's own Project Graph adapter and Effect Conformance suites from the pinned source before Motionwright's wrapper tests. A green lane proves the consumer boundary compiles and preserves the upstream contracts; it does **not** claim Graph admission, render success, or a product-level Effects PASS for a Motionwright deliverable.

## Automated desktop candidate install/extraction inspection

The Candidate Packages workflow verifies exact bundle SHA-256 against its source receipt, extracts Linux Debian/AppImage bundles, inspects real installed PE/Mach-O/ELF executable identity and desktop/bundle metadata, performs a disposable NSIS current-user installation and checks a rootless Xvfb AppImage window. Its 9 Python adversarial unit tests refuse altered archives, mismatched Semwright/source stamps, architecture/metadata substitution and fabricated GUI evidence. These checks are explicitly [automated package smoke](installed-candidate-smoke.md), **not human-installed platform acceptance**, media compatibility, notarization or publication.

## App-owned CAS filesystem shard boundary

Rust storage tests cover non-overwriting SHA-256 source admission, owner-private Unix files, symlinked staging/root/digest shard refusal, arbitrary-source path denial and the same fail-closed policy in reads, asset registration and portable export. See [CAS shard boundary](cas-shard-boundary.md). These are code-level security regressions, not end-user product acceptance.

## Local asset integrity and truthful Dependencies

An explicit read-only [local SHA-256 asset audit](asset-integrity.md) checks exact versioned asset-digest references in bounded pages. Rust tests ingest and alter real content-addressed files, inspect duplicate and missing references, reject symlinks and stale cursors, and confirm no project edits. Synthetic Chromium tests exercise opt-in paging, source revision and voice-track associations without claiming Project Graph or owner filesystem evidence. The browser demo remains Not checked.

## Native SDK read-only asset integrity scope

Native SDK integration tests import a genuine CAS blob, reference it through 19 application-owned assets and enumerate every status in three source-versioned pages without exposing raw paths or digests. They reject malformed/size-switched/forged cursors and a continuation from an older creative revision. The observer hashes only project-owned digests in a bounded worker; `complete` means list coverage, not universal byte verification or Project Graph admission. See [asset integrity](asset-integrity.md).

## Native SDK project-scope enumeration

Source-bound Rust tests enumerate 271 project-owned records with several bounded Native SDK page limits, verifying complete, ordered, nonoverlapping coverage and reject invalid offsets, wrong-scope cursors and stale creative revisions. Integration writes eleven real scenes and checks both Timeline and Canvas native observation pagination end-to-end through StudioService. Production Jobs use a separate [append-only receipt watermark and keyset history](production-receipt-pagination.md), rather than a project-revision-only offset cursor; the latest-window Studio UI stays lightweight, while a separately requested [Full history](production-jobs-history.md) view walks bounded job pages with explicit stale-receipt recovery. The browser regression uses synthetic Tauri transport to check 42 jobs over three pages and does not infer Driver Host state. See [Native SDK scope pagination](native-scope-pagination.md).

## Recent-first event journal acceptance

The storage tests create a 260-change SQLite journal and verify descending keyset pages, complete non-overlapping coverage, cross-project isolation, and backward compatibility with ascending event reads. Studio unit tests reject malformed/out-of-order pages; Chromium tests exercise recent-first pagination, older-page navigation and transient read retry through a synthetic Tauri boundary. All tests are source-SHA scoped and do not establish independent creative acceptance. See [history pagination](history-pagination.md).

## Semantic camera projection and world-space pointer editing

Canvas applies the stored scene camera center, zoom and inverse rotation to its editorial object layer, while retaining a viewport-fixed safe-frame overlay. Pure TS tests check math for identity and panned/rotated/zoomed cameras and inverse pointer movement. Chromium tests exercise camera controls and drag gestures under 2× zoom/90° camera rotation without inadvertently creating motion keyframes. This is semantic editing quality, **not rendered-frame parity or human acceptance**. See [camera projection](canvas-camera.md).

## Atomic Canvas Auto-key motion

Rust domain tests verify one authored revision for an X/Y position pair, no base-transform mutation, strict property locks, rational half-open scene timing, and rejection of invalid coordinates without half-keyframe commits. Native SDK public-operation tests validate the closed contract for agent use. Browser fixture and Chromium pointer regressions compare Auto-key on/off, exact scene-local timing, history event count, and locked-gesture no-op. Native renderer Film still rejects motion it cannot preserve exactly; see [typed motion authoring](motion-authoring.md).

## Atomic frame-based native position authoring

The Canvas inspector can create exactly four source-bound linear position keys with one revisioned Change, as opposed to manually inserting two pairs in separate commits. Rust domain and service tests cover frame-rate rational conversion, source base preservation, locking and no-overwrite semantics. Native SDK closed-schema tests verify the capability for agents, and browser tests verify explicit gating and serialized source identity. Native render/pixel support remains an independent gate.

## Native Film exact linear X/Y position motion

The pinned Film adapter admits only paired, exact-frame-aligned linear X/Y motion from an authored pose at scene-local 0 to the unchanged node base at T. Rust tests verify the actual native Settle and compiled Position tween, unsupported easing/channels/missing axes, frame alignment and starting-frame safe areas. The real pinned Broker/Driver Host E2E now seeds a visible keyed tile and independently checks 60 native frame hashes, including distinct frame 0 and frame 30 PNGs. This is native runtime evidence, **not independently approved creative quality**. See [motion projection](native-linear-position-motion.md).

## Native Film static camera pan

The pinned Film adapter now projects per-scene static camera center shifts through native subject translation when zoom=1 and rotation=0, keeping source Canvas geometry, text size, frame count and safe areas explicit. Rust tests exercise two panned scenes, native Film realization, unsupported zoom/rotation and unsafe pan bounds. This is not independent rendered pixel parity. See [static camera pan](native-film-static-pan.md).

## Experimental native MLT timeline assembly

A separate owner-only native-semantic MLT runner builds a project/sequence/track from real FFV1 sources using typed Semwright driver refs. Rust contract tests validate exact project revisions, created semantic references and fail-closed lookups. The runtime demands a native success receipt, exact lossless FFV1 codec/frames/digest and owner-root readback. It is **not a user-facing feature until its own newly added real two-segment pinned Broker/MLT E2E passes at the exact PR SHA**, and is not an H.264/AAC audio master; see [experimental timeline](mlt-native-timeline.md).

## Bounded native MLT FFV1 source preparation

A deterministic, owner-only MLT timeline recipe maps each preflight segment to an exact half-open clip interval, stable SHA-256-derived FFV1 output name and pinned landscape profile. Rust tests verify source/scene/job uniqueness, gap-free frame accounting and no generated media claims. The internal production coordinator revalidates the native source preflight before invoking the pinned Semwright MLT frames encoder per segment, verifies video-only FFV1 codec/size/FPS and checks actual artifact bytes. These are separate verified intermediates, **not** a completed multisegment MP4; see [MLT preparation](mlt-multi-segment-preparation.md).

## Bounded multisegment audio/video source readiness

A separate Rust native preflight checks that verified per-segment FFV1 files and the exact saved 48kHz stereo WAV from the app-owned CAS belong to one project/profile/creative revision. It rehashes actual source files within strict byte ceilings, checks the entire WAV RIFF chunk index, actual 48 kHz stereo PCM/float header and sample-frame count, rejects changed/missing/stale media and unimplemented mix/burn-in claims, and aligns the voice duration to the exact rational output FPS within one 48kHz sample. Tests use synthetic FFV1 file bytes and a real test WAV, so no actual MLT mux or decoded AV success is inferred. See [multisegment audio readiness](mlt-multisegment-audio-readiness.md).

## Multi-segment native MLT source conformance

Rust tests compile 33 authored Motion Canvas scenes into canonical 32+1 native Film segments and check an exact, manifest-SHA-verified 990-frame MLT assembly preflight. They reject stale project revisions, duplicated job references, segment reordering, altered native verdicts, tampered manifest bytes, missing source segments, mixed-renderer cuts and unsupported portrait-only MLT output. The desktop includes an opaque-token-bound **read-only readiness** command, with synthetic browser tests verifying exact request identity, no user-provided paths/hashes, and explicit differentiation between manifest preparation and an actual finished MP4. **This is read-only source preparation, not a rendered multi-segment master.** See [multi-segment MLT source preflight](multi-segment-preflight.md).

## Native Film semantic preflight

The native projection preflight uses the exact pinned Semwright Film adapter and current Motionwright project revision, with no native render dispatch or effect grant. Chromium tests exercise the typed read-only contract, supported/unsupported status and invalidation when creative inputs change. Native Film support is a semantic planning result, never certified renderer pixels or human acceptance; see [preflight semantics](film-preflight.md).

## Exact-scoped Program AV monitor

When both a verified Motion Canvas segment and the corresponding MLT H.264/AAC master are present for the selected versioned scene/profile, the Program monitor maps the output cut clock onto the project-global editorial playhead without altering project state. The pure-source tests cover fractional FPS, included/omitted scenes, mismatch rejection and reverse seek to authored time. Synthetic Chromium tests verify no master playback is fabricated for wrong profile, renderer or revision. See [Program native monitor](program-av-monitor.md). Installed-WebView decoder behavior and exact A/V sync still require separate acceptance.

## Bounded in-app native AV review

The desktop may read a previously authenticated Semwright H.264/AAC MP4 into WebView media memory **only** on explicit user request, using the session export token and a source/project revision match. Rust tests verify exact SHA-256 source bytes, invalid ftyp, stale project, source tampering and 16 MiB cap; synthetic Chromium tests confirm read-only token-only IPC and opt-in UI flow, but do not claim actual decoder compatibility. See [native AV review](native-av-review.md). Larger masters remain available through streaming verified MP4 export.

## Portable MP4 SHA-256 proof and offline verification

The owner-authorized desktop MP4 export can optionally write a create-new portable integrity JSON in the same directory, with a relative basename, source revision and the actual verified MP4 SHA-256. Rust tests cover manifest content, no overwrite, tamper refusal, private paths omitted and Unix mode 0600. The standard-library-only Python verifier hashes bytes in bounded chunks and rejects altered/missing files, symlinks, traversal, malformed origin/codec/FPS/digest, invalid MP4 signature and forged external anchors. Synthetic Chromium confirms explicit opt-in and a source-bound export request. These are **unsigned content-consistency checks**; they do not authenticate the creator or imply video-quality approval. See [portable MP4 proof](portable-mp4-integrity.md).

## Verified local native MP4 delivery

The desktop native MP4 delivery boundary accepts only a minted session grant for an already-completed, source-bound MLT master. Native Rust tests verify scoped source identity, refused symlinked export parents, create-new/no-overwrite, bounded SHA-256-verified streaming, and refusal to copy changed master bytes. Synthetic Chromium tests cover explicit user destination, one-time DeliverLocal grant, request parameters and revision invalidation. See [verified master export](master-verified-export.md); green tests do not certify signed distribution or human review.

## Exact native MLT entity selection

The pinned MLT project constructor supplies a default Main sequence in addition to the application-created named sequence. Its destructive `project.close` command requires trusted foreground Broker consent. The unattended verified FFV1/PCM intermediary does not ask for this permission or conceal the retained project: the exact-source E2E checks an explicit pending-cleanup receipt, and provider teardown in a disposable CI runner is not misreported as a user-approved cleanup. A native unit guard checks complete pages, exact matching names, duplicate-refusal, forged partial cursor, bounded totals and missing/empty reference denial; each mutation still rereads source-revision-bound entity references. The actual MLT E2E remains mandatory: a semantic lookup test alone does not prove real media output.

## Contiguous editorial scenes as source-bound native shots

A new exact-time Film unit gate reproduces 33 authored 1/30-second scenes and requires two complete native render segments of 32+1 frames. For a multi-scene segment, each source scene maps to an independent authored beat/shot under one Semwright Motion Canvas run Sequence; the original time spans stay constrained, each shot interval remains exact, and no editorial scene is dropped. The pinned provider supplies precise per-shot visibility within that Sequence. The strict native MLT E2E (not a synthetic acceptance) is still required to verify every actual PNG, observation, FFV1 intermediary and resulting 33-frame FFV1 + mandatory PCM transport Matroska before approval. This change is a candidate repair for observed short renders, not a CI shortcut or product-acceptance mark.

## Multi-segment native renderer diagnostics

The isolated, expensive CI lane exercises an actual 33-scene two-segment render at the pinned 30 fps, with 33 exact 1/30-second authored scene intervals, using the pinned Semwright Motion Canvas/MLT providers. Its original fixture failure came from expecting one deliverable when the canonical project has three; the corrected fixture selects the existing master without deleting valid profiles. A separate native render failure is recorded as an exact, allowlisted `RenderFailureClass` label and 1-based segment index; raw driver text cannot reach user-visible errors or public CI. CI then inspects only the pinned provider's optional exact-name private failure receipt **before disposing of its own output directory**, publishing a bounded fixed-vocabulary `safe-observation-failure.json`; five adversarial tests assert path/redaction, symlink and malformed-receipt denial. No raw stack/receipt is archived. An independent Rust unit regression rejects malicious/fabricated class names. Neither partial results nor a green synthetic regression is accepted as a successful MLT output. See [experimental MLT timeline](mlt-native-timeline.md).
## Native provider-generation loss and conservative recovery

Both the exact-SHA Motion Canvas-only renderer lane and the separate Motion Canvas → Semwright Driver Host → MLT AV lane now capture passive CI-only process and RSS samples, cgroup OOM counters and daemon exit status before owner teardown. Comparing them helps distinguish errors arising before and after MLT is provisioned, without attributing a root cause from correlations. Typed, redacted status/error timelines are retained separately from raw private receipts. Rust tests require that a failed status read after an acknowledged render start remains `outcome_known=false` and cannot be reported as confirmed RUNNING, FAILURE or SUCCESS. Synthetic Python tests reproduce Timeout followed by an inactive provider and prevent cross-job result substitution. See [provider lifecycle finding #49](reliability/provider-generation-loss.md); these tests do not establish that the pinned Driver Host bug is fixed.

## Independent portable MP4 inspection

The desktop's read-only Tauri verifier consumes an existing unsigned receipt plus a same-folder MP4. Linux CI runs its Rust unit tests for checksum matching, tampered bytes, malformed receipts, unpaired names, traversal and symlinks; browser CI runs synthetic transport tests for deliberate user action, no mutating effect grant, stale-success clearing, and accurate disclaimers. Python's standalone content-verifier tests are separate. These do not certify producer identity, media playback or any independent product acceptance ID. See [local MP4 verification](local-mp4-integrity-review.md).

## Canonical desktop AV mastering

The desktop MLT AV workflow passes only an authenticated native frame-session token and an already-saved, measured 48 kHz stereo WAV voice take ID. Rust tests validate source CAS digests, refuse stale/mono/non-WAV/unbound inputs, reject WAV length/rate/symlink/tamper, verify deterministic staging and bounded idempotent reuse of exact source SHA, refuse corrupted prior files, and check rational audio/video duration to one sample. The browser tests use an explicitly synthetic Tauri bridge to prove the UI never supplies arbitrary source paths or master evidence. Actual Semwright Broker/MLT H.264/AAC MP4 output remains covered by the exact-SHA [native AV master E2E lane](desktop-av-master.md), now with an independent [decoded media content probe](native-av-decoded-content.md) that refuses a static H.264 sequence or silent/swapped 440/660 Hz stereo AAC. That two-second fixture check does not replace independent product acceptance.

## Source-verified rendered frame readback

The native-preview Rust unit tests verify owner-root manifest SHA-256, registered single-frame PNG bytes, stale revision rejection, size/path validation and tamper rejection. The browser regression deliberately uses synthetic Tauri frame bytes, testing only UI mode, seek and error handling. The real Native Motion Canvas E2E lane independently rehashes every rendered PNG against the actual Semwright artifact manifest. See [native frame preview](native-frame-preview.md). These checks are not real-time AV playback or human visual acceptance.

## Production job-state acceptance

Job projection tests cover cancellation request versus confirmed cancellation, terminal-state non-resurrection, reconciliation after an uncertain outcome, and CURRENT/STALE applicability against the open project revision. Browser acceptance also verifies that demo mode exposes an empty truthful ledger rather than fabricated runtime jobs. Canonical driver execution remains covered by the dedicated Native Production and renderer workflows.


## Performance evidence lane

The Performance Acceptance Evidence workflow runs three unrelated briefs
(`harbor-safety`, `museum-night` and `bike-route`) at 8, 32 and 96 scenes each:
nine datasets. These benchmark-specific S/M/L labels describe the revision-ten
fixture; the separate responsiveness S editing profile is described below.

Each dataset is seeded through the real SQLite service boundary and receives ten
predefined versioned edits. Readback after reopening checks the stored revision,
scene count, and the first scene's identity and final objective. The report retains
each operation's timing, database size and `event_count`, the returned history
length. That count does not assert event-by-event journal continuity, payload replay
or a further edit after reopening.

The workflow builds each Rust benchmark in release mode before measuring its
binary with `/usr/bin/time -v`. Compiler resource use is excluded from the measured
process. The revision-ten report is written and flushed before checking whether
any measured commit exceeds 2,000 ms; equality remains admitted by this gate.
A functional assertion can still stop execution before a complete report exists.

The preview index is generated before its cache-storage timer starts. Each dataset
stores the index under its exact dependency fingerprint, validates the returned
record and actual bytes on a hit, then requires a miss for a cloned profile with
a changed width. There are nine positive lookups and nine changed-fingerprint
misses; `lookup_attempts` counts only the positive lookups. The legacy
`avoided_work_count` field totals 408 declared scene units across the nine
prebuilt indices. It does not observe a pipeline skipping 408 regenerations.
Storage cost, validation cost and bytes checked are measured separately; no
renderer frames, GPU time or wall-clock render savings are measured here.

The separate `waveform-lazy` job imports a synthetic one-hour 8 kHz PCM16
silence fixture, generates the cache-bound proxy and requests a distant page.
CI requires the source's logical file size to exceed 50 MB and `proxy_bytes`
to stay below 64 KiB. The producer calculates `proxy_bytes` as
`72 + 2 * peak_count`; it does not inspect the size of a retained proxy file.
A returned page must stay at 256 peaks or less, maximum resident memory must remain
below 192 MiB, and the cached second page must complete inside the declared
two-second bound. These measurements apply to the current fixture and algorithm
on the CI runner.

The `responsiveness-service` job builds a reference S editing profile through the
real service boundary: 12 scenes, 80 authored beats, 300 canvas nodes, a synthetic
five-minute 8 kHz PCM16 silence fixture imported as a voice track, and the default
1920x1080/30 deliverable. After five warm-up commits it records all 40 small
SQLite-backed project-commit samples,
including outliers, and measures reopening the same database. It writes and flushes
both measurements before enforcing p95 <250 ms and reopen <2,000 ms. The existing
functional revision check remains in force. The Tauri `apply_change` command
dispatches its project load and mutation through `spawn_blocking`, keeping those
SQLite operations off the async invoke executor.

The same workflow invokes the same compiled binaries with deliberately failing
budgets to check report retention. The revision-ten probe uses a zero commit
budget. Responsiveness has separate probes for a zero commit budget and a zero
reopen budget; the latter uses a 60,000 ms commit budget only to reach the reopen
guard. Each requires a nonzero exit, its specific budget diagnostic and complete
JSON with nine ten-operation datasets or all 40 samples plus the measured reopen.
These probe outputs live in separate subdirectories and never supply the positive
performance report or its derived evidence. Positive acceptance thresholds and
fixture sizes remain unchanged.

The three Rust lanes request artifact upload even after failure. Build logs,
measured-process stderr, exit codes, checkout identity, binary hashes and resource
usage are retained when produced, together with any available JSON. Missing or
incomplete measurements are not replaced with successful reports.

The independent `ui-selection` job seeds 12 scenes in Chromium and measures 60
in-browser project-rail selections from click dispatch through the Inspector update
and next animation frame. It enforces p95 <100 ms. Browser-side timing excludes
Playwright transport latency. Exact JSON measurements and failure artifacts are
retained per SHA; these runner-specific budgets are not universal device claims.

Human feedback remains NOT_RUN until actual participants exist. The benchmark
makes no comparative claims against other editors. See `docs/derived-cache.md`
for cache identity, invalidation and recovery rules, and `docs/audio.md` for
waveform semantics.


## Variants and localization evidence lane

The Variants and Localization workflow is the exact-source regression lane for delivery derivation. It runs domain invariants for crop approval, locale voice/timing separation, protected narrative cuts and dependency invalidation; canonical Film projection for portrait/localized/cut output; Native SDK contract tests; Studio unit/type/build; and the focused Chromium delivery-variant acceptance.

That lane is deliberately separate from product-level human acceptance. A green workflow proves the implemented contracts for that SHA; it does not manufacture creative approval for an actual campaign or localized voice.
