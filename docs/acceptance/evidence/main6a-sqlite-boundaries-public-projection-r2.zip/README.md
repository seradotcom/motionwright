# Selected SQLite boundary evidence

Source: 6a58102911323316544dba9a9c9e5f222f9d580b
Run: 39848087305, attempt 1. Original macOS and Windows artifacts are retained byte-for-byte.

There are five suite invocations per OS. foreign-sqlite contains five named tests; each other suite contains one. Total: nine unique method names, eighteen original test invocations and ten original suite invocations. No test was rerun to prepare this packet. Trigger variants inside one method are not counted as extra methods.

The evidence covers portable-import writer exclusion and destination ID collision, project/event SQL-abort rollback, preservation of unrelated staging, foreign SQLite rejection, source-constructed v1 upgrade, genuine-empty-store reopen and unsigned event-cursor boundaries. review/assertion-scope.json binds each observation to the exact command, stdout line/hash, test body, fixture helper and implementation symbol.

This evidence does not claim filesystem/SQLite crash atomicity, physical power loss, NTFS junction/reparse or Darwin alias/symlink authority, native production, installed product recovery, full release-candidate verification, human acceptance or complete contractual scenarios. The snapshot helper checks projects/events/receipts, not an invalidation outbox. The v1 fixture is not produced by an older binary. Project-ID exclusion is not equivalent to a stale-revision proposal conflict.

All private criterion text, coordination and intake sources are excluded. Criterion links contain identifiers and digests only. Published code snapshots are exact bytes from the integrated Git source. A source-snapshot's source-only status is preserved; actual test execution is established by its separate suite receipt and stdout.

Run python -B verify.py inside the extracted packet to verify retained hashes, closed file inventory, source inputs and original method counts. This validates evidence custody only and does not execute the product. Every original command and its scope remain available for audit.
