from pathlib import Path
import hashlib,json,re
D=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
manifest=json.loads((D/'manifest.json').read_bytes())
expected={x['path']for x in manifest['files']}|{'manifest.json'}
actual={x.relative_to(D).as_posix()for x in D.rglob('*')if x.is_file()}
assert actual==expected,(actual-expected,expected-actual)
for item in manifest['files']:
 p=(D/item['path']).resolve(strict=True);assert p.is_relative_to(D)
 b=p.read_bytes();assert len(b)==item['bytes']and sha(b)==item['sha256'],item['path']
scope=json.loads((D/'review/assertion-scope.json').read_bytes())
assert scope['unique_method_names']==9 and scope['test_invocations']==18 and scope['suite_invocations']==10
methods=set();inv=0
for osname in ['macos','windows']:
 folder=D/'original'/osname
 r=json.loads((folder/'real-SQLite-crossOS-receipt.json').read_bytes())
 snap=json.loads((folder/'source-snapshot.json').read_bytes())
 assert r['source_sha']==snap['source_sha']==manifest['source_sha']
 assert int(r['run_id'])==39848087305 and int(r['attempt'])==1
 assert r['tests_executed']==9 and r['completed_suites']==5
 assert r['human_acceptance']is False and r['filesystem_SQLite_crash_atomicity']=='NOT_ESTABLISHED'
 for i in range(6):
  si=json.loads((folder/f'source-input-{i}.json').read_bytes())
  b=(D/'source'/si['path']).read_bytes()
  assert sha(b)==si['expected_sha256']==si['git_sha256']==si['checkout_sha256']
  assert len(b)==si['git_bytes']==si['checkout_bytes']and si['bytes_equal']is True
 for suite in r['suites']:
  for stream in ['stdout','stderr']:
   p=suite[stream];assert sha((folder/p['name']).read_bytes())==p['sha256']
  text=(folder/suite['stdout']['name']).read_text(encoding='utf-8')
  names=re.findall(r'^test (\S+) \.\.\. ok$',text,re.M)
  footer=re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text,re.M)
  assert len(footer)==1 and int(footer[0][0])==len(names)and [int(x)for x in footer[0][1:4]]==[0,0,0]
  assert sorted(names)==sorted(suite['observed'])==sorted(suite['expected'])
  assert suite['exit_code']==0 and suite['status']=='PASS'
  methods.update(names);inv+=len(names)
assert len(methods)==9 and inv==18
assert all(not x['complete_criterion_ids']for x in scope['cases'])
print(json.dumps({'evidence_custody_validation':'PASS','unique_methods':9,'original_test_invocations':18,'original_suite_invocations':10,'new_product_runs':0,'human_acceptance':False,'release_authorized':False},sort_keys=True))
