"""Verify retained public Canvas service SQLite/CAS artifacts without running the product."""
import argparse,datetime,hashlib,io,json,math,pathlib,sqlite3,tempfile,zipfile
if not __debug__:raise RuntimeError("Verification requires assertions; optimized Python is refused.")
def sha(b):return hashlib.sha256(b).hexdigest()
def canon(o):return json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(",",":"),allow_nan=False).encode()
def unique_pairs(pairs):
    out={}
    for k,v in pairs:
        if k in out:raise ValueError("duplicate JSON key")
        out[k]=v
    return out
def parse(b):return json.loads(b,object_pairs_hook=unique_pairs,parse_constant=lambda s:(_ for _ in ()).throw(ValueError("nonfinite JSON number")))
def equal(a,b):
    if isinstance(a,bool) or isinstance(b,bool):return type(a) is type(b) and a==b
    if isinstance(a,(int,float)) and isinstance(b,(int,float)):
        return (not isinstance(a,float) or math.isfinite(a)) and (not isinstance(b,float) or math.isfinite(b)) and a==b
    if type(a) is not type(b):return False
    if isinstance(a,dict):return a.keys()==b.keys() and all(equal(a[k],b[k]) for k in a)
    if isinstance(a,list):return len(a)==len(b) and all(equal(x,y) for x,y in zip(a,b))
    return a==b
ap=argparse.ArgumentParser()
ap.add_argument("--archive",required=True);ap.add_argument("--sha256",required=True)
ap.add_argument("--source",required=True);ap.add_argument("--out",required=True)
args=ap.parse_args();src=pathlib.Path(args.archive);out=pathlib.Path(args.out)
assert not out.exists() and out.parent.is_dir()
raw=src.read_bytes();assert sha(raw)==args.sha256
results=[]
with zipfile.ZipFile(io.BytesIO(raw)) as z, tempfile.TemporaryDirectory(prefix="canvas-readback-",dir=out.parent) as td:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
    names=sorted(n for n in z.namelist() if n.endswith("/manifest.json"))
    assert names
    for i,n in enumerate(names):
        mb=z.read(n);m=parse(mb);parent=n.rsplit("/",1)[0];ob=z.read(parent+"/oracle.json");o=parse(ob)
        assert o["journalComplete"] is True and o["journalAfterRevisionExclusive"]==0
        assert m["lifecycle"] and all(not l["taints"] and l["exits"] and all(e["code"]==0 and e["signal"] is None for e in l["exits"]) for l in m["lifecycle"])
        listed={e["path"]:e for e in m["entries"] if e["kind"]=="file"}
        actual={p[len(parent+"/store/"):] for p in z.namelist() if p.startswith(parent+"/store/") and not p.endswith("/")}
        assert actual==set(listed) and not any(p.endswith(("-wal","-shm","-journal")) for p in actual)
        for rel,e in listed.items():
            assert rel and not rel.startswith(("/","\\")) and "\\" not in rel and ".." not in pathlib.PurePosixPath(rel).parts
            b=z.read(parent+"/store/"+rel);assert len(b)==e["sizeBytes"] and sha(b)==e["sha256"]
        entry_digest=sha(json.dumps(m["entries"],ensure_ascii=False,separators=(",",":"),allow_nan=False).encode())
        assert entry_digest==m["sourceBeforeSha256"]==m["sourceAfterSha256"]==m["snapshotSha256"]
        db=z.read(parent+"/store/"+m["databaseRelativePath"]);temp=pathlib.Path(td)/(str(i)+".sqlite3");temp.write_bytes(db)
        c=sqlite3.connect("file:"+temp.as_posix()+"?mode=ro&immutable=1",uri=True);c.row_factory=sqlite3.Row
        try:
            c.execute("PRAGMA query_only=ON");c.execute("PRAGMA temp_store=MEMORY")
            assert [r[0] for r in c.execute("PRAGMA integrity_check")]==["ok"]
            assert not list(c.execute("PRAGMA foreign_key_check"))
            project=o["project"];pid=project["id"]
            rows=list(c.execute("SELECT id,generation,revision,title,document_json FROM projects WHERE id=?",(pid,)));assert len(rows)==1
            row=dict(rows[0]);doc=parse(row["document_json"])
            assert equal({k:row[k] for k in ("id","generation","revision","title")},{k:project[k] for k in ("id","generation","revision","title")})
            assert equal(doc,project),"Project data differ"
            events=[{"revision":r["revision"],"change":parse(r["payload_json"]),"created_at":r["created_at"]} for r in c.execute("SELECT revision,payload_json,created_at FROM events WHERE project_id=? ORDER BY revision",(pid,))]
            assert equal(events,o["journal"]),"Journal data differ"
            assert [e["revision"] for e in events]==list(range(1,project["revision"]+1))
            cas=[]
            for a in doc["assets"]:
                h=a["content_sha256"];rel="blobs/sha256/"+h[:2]+"/"+h;assert rel in listed
                b=z.read(parent+"/store/"+rel);assert sha(b)==h
                cas.append({"asset_id":a["id"],"sha256":h,"bytes":len(b),"member":parent+"/store/"+rel})
        finally:c.close()
        assert temp.read_bytes()==db;temp.unlink()
        results.append({"manifest_member":n,"manifest_sha256":sha(mb),"oracle_member":parent+"/oracle.json","oracle_sha256":sha(ob),"database_sha256":sha(db),"database_bytes":len(db),"files_verified":len(listed),"project_full_typed_json_equal":True,"journal_full_typed_json_equal":True,"journal_events":len(events),"revision":project["revision"],"source_project_canonical_sha256":sha(canon(doc)),"oracle_project_canonical_sha256":sha(canon(project)),"source_journal_canonical_sha256":sha(canon(events)),"oracle_journal_canonical_sha256":sha(canon(o["journal"])),"assets":cas,"integrity":"ok","foreign_key_violations":[],"original_database_unchanged":True})
assert src.read_bytes()==raw
report={"schema":"motionwright-retained-canvas-store-readback/1","source_sha":args.source,"observed_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"archive":{"sha256":sha(raw),"bytes":len(raw)},"reader":{"file":"verify_canvas_store_archive.py","sha256":sha(pathlib.Path(__file__).read_bytes())},"sqlite_version":sqlite3.sqlite_version,"comparison":"All JSON object keys, types, strings, arrays and values are compared. Equivalent finite JSON numbers such as 1 and 1.0 compare equal; boolean and numeric values remain distinct. Canonical serialization hashes may differ for equivalent numeric spellings.","source_attribution":"The source argument is supplied by the caller. Its exact original CI checkout, run, job, artifact provenance and source lock must be verified separately; the archive checksum alone does not prove a checkout.","scope":"Readback of the selected project and its complete journal in each retained public CI store; this is not a claim about every table, distinct project IDs, a new Studio run, native rendering, installed operation or human acceptance.","counts":{"stores":len(results),"selected_project_observations":len(results),"journal_events":sum(x["journal_events"] for x in results),"asset_references":sum(len(x["assets"]) for x in results)},"results":results,"original_archive_unchanged":True,"temporary_databases_removed":True,"product_acceptance":False,"release_authorized":False}
out.write_text(json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False)+"\n",encoding="utf-8",newline="\n")
print(json.dumps({"sha256":sha(out.read_bytes()),"bytes":out.stat().st_size,"counts":report["counts"],"new_product_test_executions":0}))
