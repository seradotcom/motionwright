Original technical observations bound to Motionwright 4a529b2e8143ff409420d0afb3202ccf3c3a1caa.
Source analysis, individual CI methods, file-level Studio reports, real browser/service fixtures and archived SQLite/CAS readback retain their separate scopes.
A successful aggregate job does not certify a missing assertion or any acceptance scenario. Shared methods across groups must not be summed as unique tests.
The original CI logs, selected machine reports and public synthetic fixture artifacts needed by these observations are retained in this archive.
The full catalogue audit uses a separate frozen-snapshot observation; older full-dossier results are historical.
Private clauses, private media, internal coordination and human identity claims are absent.
No product acceptance, installed session, physical native output or release authorization is inferred beyond the explicit per-record evidence.
