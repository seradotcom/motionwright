Conformance source dossier
Source: 6a58102911323316544dba9a9c9e5f222f9d580b
The package contains an original-source inventory observation, retained selected verifier results and exact-source CI provenance. It is not product acceptance or a new full test run.
396 records / 1652 canonical field hashes / 506 original links are reconciled. Original contract text is omitted.
Nine local synthetic controls and one distinct positive CLI fixture are retained. Current source and artifact identities are explicit; old evidence remains historical.
The existing history guard has a demonstrated canonical-type gap. Its proposed repair is not attributed to this integrated source.
A historical observation file is retained and hashed, but is absent at the source where it was listed as a definition; this remains an explicit provenance qualification.
The 22 field observations are proposals. Separate authorized technical review is pending; there is no human signature, scenario PASS or release authorization.
Reproduction: checkout the exact source, inspect the listed functions and run only the retained selectors when a relevant code/input change requires it. Original API bytes and private-catalog recomputation drivers remain in the authorized private dossier. Public readers can verify all retained members against manifest.json, source paths against Git, and the disclosed criterion hashes against an authorized original catalogue.
