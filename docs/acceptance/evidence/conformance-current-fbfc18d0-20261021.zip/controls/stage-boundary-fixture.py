import unittest
import test_conformance_policy as testmod
import conformance_policy as policy
class ExplicitStageBoundary(unittest.TestCase):
 def test_compilation_receipt_cannot_satisfy_native_execution(self):
  f=testmod.ConformancePolicyTests(methodName="test_complete_technical_review_does_not_require_human_or_grant_acceptance")
  f.setUp();self.addCleanup(f.doCleanups)
  f.index["execution_profiles"].update({"locked-consumer-compilation":{"kind":"integration"},"native-host-execution":{"kind":"native"}})
  f.index["records"][0]["execution"].update(kind="integration",profile="locked-consumer-compilation")
  f.assessment["technical_verification"]["execution_kinds"]=["integration"]
  f.populate_sufficiency()
  for p in f.index["verification_profiles"].values():p["obligations"]["observed-result"]["execution_profiles"]=["native-host-execution"]
  for review in f.index["sufficiency_reviews"]:review["oracle_profile_sha256"]=policy.canonical_digest(f.index["verification_profiles"][review["criterion_id"]])
  with self.assertRaisesRegex(ValueError,"execution surface"):f.validate()

if __name__=="__main__": unittest.main(verbosity=2)
