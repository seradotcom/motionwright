#!/usr/bin/env python3
"""Acceptance intake tests run without private spec text or heavyweight runtimes."""
from __future__ import annotations

import importlib.util
from pathlib import Path
import copy
import os
import tempfile
import unittest
from unittest.mock import patch

SCRIPT = Path(__file__).resolve().parents[1] / "acceptance_session.py"
SPEC = importlib.util.spec_from_file_location("acceptance_session", SCRIPT)
assert SPEC is not None and SPEC.loader is not None
module = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(module)

SOURCE_SHA = "a" * 40
UTC = "2026-10-08T20:00:00+00:00"


class IntakeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.manifest = module.create_session(source_sha=SOURCE_SHA, executed_by="operator-fixture")

    def write_evidence(self, relative="ACC-001/screenshot.png", data=b"fake-evidence-fixture"):
        path = self.root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return module.fingerprint(self.root, relative)

    def test_unreviewed_session_cannot_auto_pass(self):
        self.assertEqual(len(self.manifest["cases"]), 60)
        self.assertEqual([case["id"] for case in self.manifest["cases"]], module.EXPECTED_IDS)
        self.assertEqual(self.manifest["source"]["semwright_sha"], module.locked_semwright_revision())
        self.assertFalse(self.manifest["source"]["private_spec_text_embedded"])
        totals = module.validate_session(self.manifest, evidence_root=self.root)
        self.assertEqual(totals, {"NOT_RUN": 60, "PASS": 0, "FAIL": 0, "BLOCKED": 0})

    def approve(self):
        case = self.manifest["cases"][0]
        case.update({
            "status": "PASS",
            "executed_by": "Operator A",
            "executed_at_utc": UTC,
            "reviewed_by": "Reviewer B",
            "reviewed_at_utc": UTC,
            "independent": True,
            "notes": "Verified the installed desktop's frame-exact scenario against the private case criteria",
            "evidence": [self.write_evidence()],
        })
        return case

    def test_complete_independent_pass_with_exact_sha_is_accepted(self):
        self.approve()
        totals = module.validate_session(self.manifest, evidence_root=self.root)
        self.assertEqual(totals["PASS"], 1)
        self.assertEqual(totals["NOT_RUN"], 59)

    def test_self_approved_pass_is_not_independent(self):
        case = self.approve()
        case["reviewed_by"] = "operator a"
        with self.assertRaisesRegex(module.IntakeError, "independently identified reviewer"):
            module.validate_session(self.manifest, evidence_root=self.root)

    def test_unreviewed_pass_is_rejected_even_with_a_real_file(self):
        case = self.approve()
        case["independent"] = False
        with self.assertRaisesRegex(module.IntakeError, "independently identified reviewer"):
            module.validate_session(self.manifest, evidence_root=self.root)

    def test_missing_pass_evidence_is_never_treated_as_complete(self):
        case = self.approve()
        case["evidence"] = []
        with self.assertRaisesRegex(module.IntakeError, "at least one actual evidence"):
            module.validate_session(self.manifest, evidence_root=self.root)

    def test_tampered_evidence_fails_closed(self):
        self.approve()
        (self.root / "ACC-001/screenshot.png").write_bytes(b"tampered")
        with self.assertRaisesRegex(module.IntakeError, "evidence has changed"):
            module.validate_session(self.manifest, evidence_root=self.root)

    def test_missing_private_spec_or_source_pin_cannot_be_forged(self):
        self.manifest["source"]["semwright_sha"] = "f" * 40
        with self.assertRaisesRegex(module.IntakeError, "Semwright source SHA"):
            module.validate_session(self.manifest, evidence_root=self.root)

    def test_reordered_or_duplicated_cases_fail_closed(self):
        case = copy.deepcopy(self.manifest["cases"][0])
        self.manifest["cases"][1] = case
        with self.assertRaisesRegex(module.IntakeError, "each of the exact 60"):
            module.validate_session(self.manifest, evidence_root=self.root)

    def test_traversal_and_symlink_are_rejected_before_hashing(self):
        (self.root / "sub").mkdir()
        outside = self.root.parent / (self.root.name + "-outside-evidence.txt")
        outside.write_bytes(b"private evidence")
        self.addCleanup(lambda: outside.unlink(missing_ok=True))
        with self.assertRaisesRegex(module.IntakeError, "relative|parent"):
            module.fingerprint(self.root, "../" + outside.name)
        with self.assertRaisesRegex(module.IntakeError, "relative|parent"):
            module.fingerprint(self.root, "/etc/hosts")
        link = self.root / "sub" / "linked.txt"
        try:
            link.symlink_to(outside)
        except OSError:
            # Non-admin Windows cannot create symlinks. Test the same
            # fail-closed path without requesting developer privileges.
            actual_is_symlink = Path.is_symlink
            with patch.object(
                Path, "is_symlink", autospec=True,
                side_effect=lambda path: path == link or actual_is_symlink(path),
            ):
                with self.assertRaisesRegex(module.IntakeError, "symlink"):
                    module.fingerprint(self.root, "sub/linked.txt")
        else:
            with self.assertRaisesRegex(module.IntakeError, "symlink"):
                module.fingerprint(self.root, "sub/linked.txt")

    def test_fail_and_blocked_require_real_evidence_or_notes(self):
        fail_case = self.manifest["cases"][0]
        fail_case.update({
            "status": "FAIL",
            "executed_by": "Operator A",
            "executed_at_utc": UTC,
            "notes": "Observed an actual render mismatch",
            "evidence": [self.write_evidence()],
        })
        blocked = self.manifest["cases"][1]
        blocked.update({
            "status": "BLOCKED",
            "executed_by": "Operator A",
            "executed_at_utc": UTC,
            "notes": "Device not available in the isolated acceptance environment",
        })
        totals = module.validate_session(self.manifest, evidence_root=self.root)
        self.assertEqual(totals["FAIL"], 1)
        self.assertEqual(totals["BLOCKED"], 1)
        self.assertEqual(totals["PASS"], 0)
        blocked["notes"] = ""
        with self.assertRaisesRegex(module.IntakeError, "blocking reason"):
            module.validate_session(self.manifest, evidence_root=self.root)

    def test_evidence_paths_are_validated_with_boundaries(self):
        with self.assertRaisesRegex(module.IntakeError, "relative|parent"):
            module.fingerprint(self.root, "sub/./evidence.png")
        with self.assertRaisesRegex(module.IntakeError, "relative|parent"):
            module.fingerprint(self.root, "sub/../evidence.png")
        with self.assertRaisesRegex(module.IntakeError, "backslashes"):
            module.fingerprint(self.root, r"sub\evidence.png")

    def test_case_status_must_use_utc_timestamps(self):
        case = self.approve()
        case["executed_at_utc"] = "2026-10-08"
        with self.assertRaisesRegex(module.IntakeError, "execution time"):
            module.validate_session(self.manifest, evidence_root=self.root)

    def test_review_must_follow_execution_and_contain_rationale(self):
        case = self.approve()
        case["reviewed_at_utc"] = "2026-10-08T19:00:00+00:00"
        with self.assertRaisesRegex(module.IntakeError, "cannot precede"):
            module.validate_session(self.manifest, evidence_root=self.root)
        case["reviewed_at_utc"] = UTC
        case["notes"] = ""
        with self.assertRaisesRegex(module.IntakeError, "review rationale"):
            module.validate_session(self.manifest, evidence_root=self.root)

    def test_local_timezone_falsely_labeled_utc_is_rejected(self):
        case = self.approve()
        case["executed_at_utc"] = "2026-10-08T14:00:00-06:00"
        with self.assertRaisesRegex(module.IntakeError, "execution time"):
            module.validate_session(self.manifest, evidence_root=self.root)

    def test_private_case_cannot_reuse_file_from_unrelated_case(self):
        first = self.approve()
        second = self.manifest["cases"][1]
        second.update({
            "status": "PASS",
            "executed_by": "Operator A",
            "executed_at_utc": UTC,
            "reviewed_by": "Reviewer B",
            "reviewed_at_utc": UTC,
            "independent": True,
            "notes": "Independent review rationale for another private scenario",
            "evidence": copy.deepcopy(first["evidence"]),
        })
        with self.assertRaisesRegex(module.IntakeError, "own case directory"):
            module.validate_session(self.manifest, evidence_root=self.root)

    def test_same_case_cannot_count_duplicate_file_as_separate_evidence(self):
        case = self.approve()
        case["evidence"].append(copy.deepcopy(case["evidence"][0]))
        with self.assertRaisesRegex(module.IntakeError, "duplicate evidence path"):
            module.validate_session(self.manifest, evidence_root=self.root)

    def test_fail_cannot_claim_foreign_case_evidence_either(self):
        case = self.manifest["cases"][1]
        case.update({
            "status": "FAIL",
            "executed_by": "Operator A",
            "executed_at_utc": UTC,
            "notes": "Observed failing result",
            "evidence": [self.write_evidence("ACC-001/screenshot.png")],
        })
        with self.assertRaisesRegex(module.IntakeError, "own case directory"):
            module.validate_session(self.manifest, evidence_root=self.root)

    def test_malformed_case_missing_id_refused_as_intake_error(self):
        del self.manifest["cases"][0]["id"]
        with self.assertRaisesRegex(module.IntakeError, "60 canonical"):
            module.validate_session(self.manifest, evidence_root=self.root)

    def test_duplicate_json_fields_in_private_session_are_rejected(self):
        private = self.root / "session.json"
        original = __import__("json").dumps(self.manifest)
        private.write_text(original.replace(
            '"schema_version": 1,',
            '"schema_version": 1, "schema_version": 1,', 1,
        ), encoding="utf-8")
        with self.assertRaisesRegex(module.IntakeError, "Duplicate"):
            module.load_private_manifest(private)

    def test_oversized_private_session_is_refused_before_json_parse(self):
        private = self.root / "session.json"
        private.write_bytes(b"x" * (module.MAX_MANIFEST_BYTES + 1))
        with self.assertRaisesRegex(module.IntakeError, "bounded"):
            module.load_private_manifest(private)

    def test_synthetic_source_sha_cannot_be_admitted_as_current_checkout(self):
        from unittest.mock import patch
        with patch.object(module, "checked_head", return_value="b" * 40), patch.object(
            module, "assert_clean_source_checkout", return_value=None
        ):
            with self.assertRaisesRegex(module.IntakeError, "current Git checkout"):
                module.checked_intake_source(SOURCE_SHA)
            self.assertEqual(module.checked_intake_source("b" * 40), "b" * 40)
            self.assertEqual(module.checked_intake_source(None), "b" * 40)

    def test_dirty_tracked_checkout_cannot_initialize_exact_sha_acceptance(self):
        from unittest.mock import patch
        with patch.object(module, "checked_head", return_value=SOURCE_SHA), patch.object(
            module, "assert_clean_source_checkout",
            side_effect=module.IntakeError("tracked checkout dirty"),
        ):
            with self.assertRaisesRegex(module.IntakeError, "tracked checkout dirty"):
                module.checked_intake_source(SOURCE_SHA)

    def test_not_run_cannot_claim_execution_identity_or_review_time(self):
        case = self.manifest["cases"][0]
        case["executed_by"] = "claimed operator"
        with self.assertRaisesRegex(module.IntakeError, "NOT_RUN"):
            module.validate_session(self.manifest, evidence_root=self.root)
        case["executed_by"] = ""
        case["executed_at_utc"] = UTC
        with self.assertRaisesRegex(module.IntakeError, "NOT_RUN"):
            module.validate_session(self.manifest, evidence_root=self.root)

    def test_json_duplicate_nested_case_status_is_not_silently_accepted(self):
        private = self.root / "nested.json"
        import json
        original = json.dumps(self.manifest)
        private.write_text(original.replace(
            '"status": "NOT_RUN",',
            '"status": "NOT_RUN", "status": "PASS",',
            1,
        ), encoding="utf-8")
        with self.assertRaisesRegex(module.IntakeError, "Duplicate"):
            module.load_private_manifest(private)

    def test_verify_rejects_forged_source_sha_after_valid_initialization(self):
        import json
        file = self.root / "private-review.json"
        file.write_text(json.dumps(self.manifest), encoding="utf-8")
        with patch.object(module, "checked_head", return_value="b" * 40), patch.object(
            module, "assert_clean_source_checkout", return_value=None
        ):
            with self.assertRaisesRegex(module.IntakeError, "current Git checkout"):
                module.verify_private_session(file, evidence_root=self.root)

    def test_verify_requires_clean_checkout_even_for_matching_source(self):
        import json
        file = self.root / "private-review.json"
        file.write_text(json.dumps(self.manifest), encoding="utf-8")
        with patch.object(module, "checked_head", return_value=SOURCE_SHA), patch.object(
            module, "assert_clean_source_checkout",
            side_effect=module.IntakeError("Cannot initialize intake from a dirty tracked checkout")
        ):
            with self.assertRaisesRegex(module.IntakeError, "dirty tracked checkout"):
                module.verify_private_session(file, evidence_root=self.root)

    def test_verify_matching_clean_source_keeps_every_case_not_run(self):
        import json
        file = self.root / "private-review.json"
        file.write_text(json.dumps(self.manifest), encoding="utf-8")
        with patch.object(module, "checked_head", return_value=SOURCE_SHA), patch.object(
            module, "assert_clean_source_checkout", return_value=None
        ):
            status = module.verify_private_session(file, evidence_root=self.root)
        self.assertEqual(status["PASS"], 0)
        self.assertEqual(status["NOT_RUN"], 60)

    def test_verify_refuses_checkout_changed_during_evidence_hashing(self):
        import json
        self.approve()
        manifest = self.root / "private-review.json"
        manifest.write_text(json.dumps(self.manifest), encoding="utf-8")
        # First source check succeeds. After the real PASS evidence is read,
        # HEAD has changed and the original receipt must not be reported.
        real_fingerprint = module.fingerprint
        with patch.object(module, "checked_head",
                          side_effect=[SOURCE_SHA, "b" * 40]) as head, \
             patch.object(module, "assert_clean_source_checkout",
                          return_value=None), \
             patch.object(module, "fingerprint",
                          wraps=real_fingerprint) as evidence:
            with self.assertRaisesRegex(module.IntakeError, "current Git checkout"):
                module.verify_private_session(manifest, evidence_root=self.root)
        self.assertEqual(head.call_count, 2)
        self.assertEqual(evidence.call_count, 1)

    def test_verify_refuses_checkout_dirtied_during_evidence_verification(self):
        import json
        manifest = self.root / "private-review.json"
        manifest.write_text(json.dumps(self.manifest), encoding="utf-8")
        with patch.object(module, "checked_head", return_value=SOURCE_SHA), \
             patch.object(module, "assert_clean_source_checkout",
                          side_effect=[None, module.IntakeError("checkout changed during verification")]) as clean:
            with self.assertRaisesRegex(module.IntakeError, "checkout changed"):
                module.verify_private_session(manifest, evidence_root=self.root)
        self.assertEqual(clean.call_count, 2)

    def test_malformed_status_collection_is_rejected_as_intake_error(self):
        self.manifest["cases"][0]["status"] = ["PASS"]
        with self.assertRaisesRegex(module.IntakeError, "unknown acceptance status"):
            module.validate_session(self.manifest, evidence_root=self.root)

    def test_manifest_inside_public_checkout_refused_before_parsing(self):
        import json
        file = self.root / "session.json"
        file.write_text(json.dumps(self.manifest), encoding="utf-8")
        with patch.object(module, "ROOT", self.root):
            with self.assertRaisesRegex(module.IntakeError, "outside the public checkout"):
                module.load_private_manifest(file)

    def test_evidence_root_inside_public_checkout_refused_even_if_not_run(self):
        with patch.object(module, "ROOT", self.root):
            with self.assertRaisesRegex(module.IntakeError, "outside the public checkout"):
                module.validate_session(self.manifest, evidence_root=self.root)

    def test_fingerprint_cannot_read_private_evidence_from_public_checkout(self):
        self.write_evidence()
        with patch.object(module, "ROOT", self.root):
            with self.assertRaisesRegex(module.IntakeError, "outside the public checkout"):
                module.fingerprint(self.root, "ACC-001/screenshot.png")

    def test_source_lock_requires_full_commit(self):
        with self.assertRaisesRegex(module.IntakeError, "source_sha"):
            module.create_session(source_sha="main")


if __name__ == "__main__":
    unittest.main()
