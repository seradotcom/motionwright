"""Read-only candidate audit. Original catalogs stay private; public outputs contain hashes and scoped observations."""
from pathlib import Path, PurePosixPath
import ast,collections,copy,datetime,hashlib,io,json,os,re,subprocess,sys,zipfile
def sha(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def enc(d):return (json.dumps(d,sort_keys=True,ensure_ascii=False,separators=(",",":"))+"\n").encode()
def readj(p):return json.loads(Path(p).read_text(encoding="utf-8-sig"))
def pinned(d):
 b=Path(d["path"]).read_bytes();assert sha(b)==d["sha256"],("pinned_input",Path(d["path"]).name)
 return b
cfgraw=Path(sys.argv[1]).read_bytes();assert sha(cfgraw)==sys.argv[2]
C=json.loads(cfgraw);W=Path(C["worktree"]);OUT=Path(C["output"]);OUT.mkdir(exist_ok=False)
PUB=OUT/"public";PUB.mkdir();started=now()
def save(name,d,public=True):
 p=(PUB if public else OUT)/name;p.parent.mkdir(parents=True,exist_ok=True)
 b=d if isinstance(d,bytes)else enc(d)
 with p.open("xb")as f:f.write(b);f.flush();os.fsync(f.fileno())
 assert p.read_bytes()==b
 return {"file":name,"sha256":sha(b),"bytes":len(b)}
env={k:v for k,v in os.environ.items()if not k.upper().startswith("GIT_")}
env.update(GIT_CONFIG_NOSYSTEM="1",GIT_CONFIG_GLOBAL=os.devnull,GIT_NO_REPLACE_OBJECTS="1",GIT_NO_LAZY_FETCH="1",GIT_OPTIONAL_LOCKS="0",GIT_TERMINAL_PROMPT="0",PYTHONDONTWRITEBYTECODE="1")
def git(*args,input=None):
 p=subprocess.run(["git","--no-replace-objects","--no-optional-locks","-c","core.fsmonitor=false","-C",str(W),*args],input=input,capture_output=True,env=env,timeout=180)
 assert p.returncode==0,(args,p.stderr.decode(errors="replace")[:300]);return p.stdout
def public_file(rel):
 q=PurePosixPath(rel)
 assert q.as_posix()==rel and not q.is_absolute()and ":"not in rel and "\\"not in rel and ".."not in q.parts
 p=W.joinpath(*q.parts);assert p.resolve().is_relative_to(W.resolve());return p
N=C["ledger_sha256"];raw={n:public_file(n).read_bytes()for n in N};assert {n:sha(b)for n,b in raw.items()}==N
docs={n:json.loads(b)for n,b in raw.items()};ip="docs/acceptance/technical-evidence.json";idx=docs[ip]
BASE=idx["source"]["motionwright_sha"];assert git("rev-parse","HEAD").decode().strip()==BASE
tree=git("rev-parse","HEAD^{tree}").decode().strip()
remote=git("ls-remote","origin","refs/heads/main").decode().split()[0]
sys.path.insert(0,str(W/"tooling"))
import conformance_policy as policy
import conformance_history_guard as history
rows={}
for n,d in docs.items():
 if n==ip:continue
 assert d["technical_evidence_index"]["sha256"]==sha(raw[ip].replace(b"\r\n",b"\n"))
 for k in("requirements","cases","expansion_cases"):
  for row in d.get(k,[]):assert row["id"]not in rows;rows[row["id"]]=row
assert len(rows)==396 and len(idx["criteria"])==1652
orig=json.loads(pinned(C["original_audit"]));catalogs={k:json.loads(pinned(d))for k,d in C["catalogs"].items()}
portfolio=json.loads(pinned(C["portfolio"]));prrows={r["id"]:r for r in portfolio["rows"]}
assert set(prrows)==set(rows)
actual_originals={};clause_map={};owner_counts=collections.Counter();private_rows=[];public_rows=[]
for old in orig["rows"]:
 ident=old["id"];s=old["original_source"];original=catalogs[s["relative_file"]][s["collection"]][s["index"]]
 assert original==old["original_record"]==prrows[ident]["source"]["original_record"]
 assert policy.canonical_digest(original)==old["source_record_sha256"]==idx["contracts"][ident]["source_record_sha256"]==rows[ident]["source_record_sha256"]
 assert old["ownership"]["assigned_leads"]==prrows[ident]["ownership"]["assigned_leads"]
 if s["kind"]=="requirement":owner_counts.update(old["ownership"]["assigned_leads"])
 actual_originals[ident]=original
 fields={f["id"]:f for f in rows[ident]["technical_assessment"]["criteria"]}
 assert set(fields)=={f["id"]for f in old["criteria"]}
 for f in old["criteria"]:
  val=original
  for key in f["original_json_pointer"].strip("/").split("/"):
   key=key.replace("~1","/").replace("~0","~");val=val[int(key)]if isinstance(val,list)else val[key]
  assert isinstance(val,str)and val==f["original_text"]
  h=sha(val.encode());assert h==f["source_clause_sha256"]==idx["criteria"][f["id"]]==fields[f["id"]]["source_clause_sha256"]
  clause_map[f["id"]]=h
 a=rows[ident]["technical_assessment"]
 assert a["release_decision"]=="not_granted"and a["contract_acceptance"]["status"]=="open"
 private_rows.append({"id":ident,"original":original,"ownership":prrows[ident]["ownership"],"assessment":a})
 public_rows.append({"id":ident,"kind":s["kind"],"original_record_sha256":policy.canonical_digest(original),"original_clause_sha256":{k:v for k,v in clause_map.items()if k.startswith(ident+"#/")},"assessment":a})
assert len(actual_originals)==396 and clause_map==idx["criteria"]
assert dict(owner_counts)=={"A2":101,"A3":96,"A4":72,"A5":3}
edges=set()
for ident,r in actual_originals.items():
 for cid in r.get("acceptance_ids",[]):edges.add((cid,ident))
 for rid in r.get("requirement_ids",[]):edges.add((ident,rid))
 if "requirement_id"in r:edges.add((ident,r["requirement_id"]))
assert len(edges)==506 and edges=={(e["case_id"],e["requirement_id"])for e in idx["normative_edges"]}
assert edges=={(e["acceptance_id"],e["requirement_id"])for e in portfolio["links"]}
save("all-rows.private.json",private_rows,False)
save("rows.json",public_rows)
print(json.dumps({"stage":"originals","rows":396,"clauses":1652,"edges":506,"ownership":dict(owner_counts)}),flush=True)
records={r["id"]:r for r in idx["records"]};assert len(records)==1668 and len(idx["sufficiency_reviews"])==950
specs=set()
for r in records.values():
 specs.add(r["source"]["motionwright_sha"]+":SOURCE_LOCK.json")
 for k in("definitions","source_inputs","binary_source_dependencies"):
  specs.update(r["source"]["motionwright_sha"]+":"+x["path"]for x in r.get(k,[]))
gitdata={};ordered=sorted(specs)
for start in range(0,len(ordered),100):
 chunk=ordered[start:start+100];blob=git("cat-file","--batch",input=("\n".join(chunk)+"\n").encode());at=0
 for spec in chunk:
  end=blob.index(b"\n",at);head=blob[at:end].split();at=end+1
  if head[-1]==b"missing":gitdata[spec]={"missing":True};continue
  assert len(head)==3 and head[1]==b"blob",(spec,head)
  size=int(head[2]);data=blob[at:at+size];at+=size+1
  gitdata[spec]={"sha256":sha(data.replace(b"\r\n",b"\n")),"raw_sha256":sha(data),"bytes":size,"blob":head[0].decode()}
 assert at==len(blob)
print(json.dumps({"stage":"git_objects","unique_original_bindings":len(gitdata)}),flush=True)
physical={}
def actual(rel):
 if rel not in physical:
  p=public_file(rel)
  physical[rel]=None if not p.is_file()else sha(p.read_bytes().replace(b"\r\n",b"\n"))
 return physical[rel]
source_errors=[];source_results=[];stale={};source_binding_count=0
art_specs={};member_specs={}
for r in records.values():
 rid=r["id"];rsha=r["source"]["motionwright_sha"];missing=[];changed=[];artifact_definitions=[]
 lock=gitdata[rsha+":SOURCE_LOCK.json"]
 if lock.get("sha256")!=r["source"]["source_lock_sha256"]:missing.append({"path":"SOURCE_LOCK.json","role":"source_lock","observed":lock})
 for k in("definitions","source_inputs","binary_source_dependencies"):
  for x in r.get(k,[]):
   g=gitdata[rsha+":"+x["path"]];israw=k=="binary_source_dependencies";key="raw_sha256"if israw else"sha256"
   source_binding_count+=1
   if g.get(key)!=x["sha256"]:
    candidates=[a for a in r["artifacts"]if a.get("path")==x["path"]and a["sha256"]==x["sha256"]and "member"not in a]
    if k=="definitions"and g.get("missing")and len(candidates)==1:
     ab=public_file(x["path"]).read_bytes();ad=json.loads(ab)
     assert sha(ab)==x["sha256"]and ad["source"]==r["source"]and isinstance(ad.get("oracle"),list)and ad["oracle"]
     artifact_definitions.append({"path":x["path"],"sha256":sha(ab),"source":ad["source"],"binding_kind":"retained_artifact_oracle_not_product_git_input","original_git_path_present":False})
    else:missing.append({"path":x["path"],"role":k,"expected":x["sha256"],"observed":g})
   if israw:
    if x.get("git_blob")and g.get("blob")!=x["git_blob"]:missing.append({"path":x["path"],"role":"raw_blob"})
   elif actual(x["path"])!=x["sha256"]:changed.append({"path":x["path"],"role":k})
 for a in r["artifacts"]:
  ap=a["path"];assert ap not in art_specs or art_specs[ap]==a["sha256"];art_specs[ap]=a["sha256"]
  if "member"in a:
   key=(ap,a["member"]);assert key not in member_specs or member_specs[key]==a["member_sha256"];member_specs[key]=a["member_sha256"]
 if missing:source_errors.append({"record":rid,"mismatches":missing})
 if changed:stale[rid]=["product source input or definition changed; historical evidence retained"]
 source_results.append({"id":rid,"canonical_sha256":policy.canonical_digest(r),"source":r["source"],"execution":r["execution"],"criterion_ids":r["criterion_ids"],"complete_criterion_ids":r["complete_criterion_ids"],"original_bindings_checked":sum(len(r.get(k,[]))for k in("definitions","source_inputs","binary_source_dependencies")),"original_source_mismatches":missing,"retained_artifact_definitions":artifact_definitions,"changed_current_bindings":changed,"artifact_references":r["artifacts"]})
arts=[];artifact_errors=[]
for rel,digest in sorted(art_specs.items()):
 b=public_file(rel).read_bytes();ok=sha(b)==digest
 row={"path":rel,"sha256":sha(b),"bytes":len(b),"matches":ok,"members":[]}
 if not ok:artifact_errors.append({"path":rel,"expected":digest,"observed":sha(b)})
 desired=[(m,h)for(p,m),h in member_specs.items()if p==rel]
 if desired:
  with zipfile.ZipFile(io.BytesIO(b))as z:
   assert z.testzip()is None and len(z.namelist())==len(set(z.namelist()))
   for m,h in desired:
    mb=z.read(m);match=sha(mb)==h
    row["members"].append({"name":m,"sha256":sha(mb),"bytes":len(mb),"matches":match})
    if not match:artifact_errors.append({"path":rel,"member":m,"expected":h,"observed":sha(mb)})
 arts.append(row)
save("artifact-readback.json",arts);save("record-source-and-scope-census.json",source_results)
print(json.dumps({"stage":"evidence","records":len(records),"source_bindings":source_binding_count,"artifact_files":len(arts),"archive_members":len(member_specs),"source_errors":len(source_errors),"artifact_errors":len(artifact_errors)}),flush=True)
validation=copy.deepcopy(idx);validation["_stale_evidence_records"]=stale
policy.validate_sufficiency_reviews(validation,records);policy.validate_catalog_links(validation,list(rows.values()))
for row in rows.values():policy.validate_assessment(row["technical_assessment"],row["id"],validation,records)
old={n:readj(Path(C["transaction_preimage"])/n)for n in N}
integrated={n:json.loads(git("show",BASE+":"+n))for n in N}
guards={"previous_candidate":history.inspect(old,docs),"integrated_main":history.inspect(integrated,docs)}
assert all(g["result"]=="history_preserved"and g["ledger_rows_verified"]==396 for g in guards.values())
assert idx["records"][:len(old[ip]["records"])]==old[ip]["records"]and idx["sufficiency_reviews"][:len(old[ip]["sufficiency_reviews"])]==old[ip]["sufficiency_reviews"]
pr=json.loads(pinned(C["pr_capture"]));assert pr["count"]==111 and len(pr["pull_requests"])==111 and pr["main_observed"]==BASE
raw_pr_pages=[]
for d in pr["pages"]:
 b=(Path(C["pr_capture"]["path"]).parent/d["file"]).read_bytes();assert sha(b)==d["sha256"];raw_pr_pages.append({"file":d["file"],"sha256":sha(b),"bytes":len(b)})
paths_to_rows=collections.defaultdict(set)
for ident,row in rows.items():
 a=row["technical_assessment"]
 for path in a["implementation"].get("referenced_paths",[]):paths_to_rows[path].add(ident)
 for f in a["criteria"]:
  for rid in f.get("evidence_ids",[]):
   for k in("definitions","source_inputs"):
    for x in records[rid].get(k,[]):paths_to_rows[x["path"]].add(ident)
pr_results=[]
for v in pr["pull_requests"]:
 assert not v["files"]["pageInfo"]["hasNextPage"]
 overlap={x["path"]:sorted(paths_to_rows[x["path"]])for x in v["files"]["nodes"]if x["path"]in paths_to_rows}
 unmapped=[x["path"]for x in v["files"]["nodes"]if x["path"]not in paths_to_rows]
 pr_results.append({k:v[k]for k in("number","url","baseRefName","baseRefOid","headRefName","headRefOid","isDraft","mergeable","updatedAt")}|
 {"changed_paths":[x["path"]for x in v["files"]["nodes"]],"path_overlap":overlap,"unmapped_paths_pending_reconciliation":unmapped,"integration_or_behavior_inferred":False})
save("open-pr-impact.json",{"observed_at_utc":pr["at_utc"],"main_observed":pr["main_observed"],"raw_page_digests":raw_pr_pages,"prs":pr_results,"method":"Exact changed-path overlap with declared implementation and bound evidence inputs. Unmapped paths remain pending; shared inputs may affect many rows. No integration inferred."})
pol=json.loads(pinned(C["policy_receipt"]));assert pol["candidate_ledger_sha256"]==N and pol["passed"]==4 and pol["failed"]==1
pols=[]
for p in pol["policies"]:
 source_b=public_file("tooling/"+p["policy"]).read_bytes().replace(b"\r\n",b"\n");assert sha(source_b)==p["source_sha256"]
 a=save("policies/"+p["policy"]+".stdout.original",pinned(p["stdout"]));b=save("policies/"+p["policy"]+".stderr.original",pinned(p["stderr"]))
 pols.append({"policy":p["policy"],"source_sha256":p["source_sha256"],"start":p["start"],"end":p["end"],"exit_code":p["exit_code"],"stdout":a,"stderr":b})
save("candidate-policy-observations.json",{"policies":pols,"passed":4,"failed":1,"source_policy_preexisting_references":"Failure retained and reported; no exemption or history change applied.","security_audit_checked":False,"candidate_acceptance_granted":False})
build_path="docs/acceptance/evidence/conformance-a4eb-locked-consumers-20261022.zip"
with zipfile.ZipFile(public_file(build_path))as z:
 obs=json.loads(z.read("review/locked-consumer-observation.json"));jobdoc=json.loads(z.read("ci/jobs.original.json"));run=json.loads(z.read("ci/run.original.json"));log=z.read("ci/rust.original.log")
 assert sha(log)=="8c24b775ea4a750cc7b052c7fc0e5a7471cc02723efb73d474949b8eae70dce9"
 assert run["head_sha"]==BASE and run["id"]==39802244854 and run["run_attempt"]==1 and run["conclusion"]=="success"
 job=next(j for j in jobdoc["jobs"]if j["id"]==119907366617)
 step=next(s for s in job["steps"]if s["number"]==5)
 assert job["conclusion"]=="success"and step==obs["step"]and step["conclusion"]=="success"
 lines=log.splitlines(keepends=True);selected=obs["checkout"]+obs["cache_miss"]+obs["command"]+list(obs["consumer_compilations"].values())+[obs["finished"]]
 for x in selected:
  line=lines[x["line_number"]-1]
  assert sha(line)==x["original_line_sha256"]and len(line)==x["original_line_bytes"]
 assert len(obs["consumer_compilations"])==4 and obs["source"]==idx["source"]
 parents={rid:{"canonical_sha256":policy.canonical_digest(records[rid]),"criterion_ids":records[rid]["criterion_ids"],"profile":records[rid]["execution"]["profile"]}for rid in("a4-src-0031","a4-build-0002")}
 sdk={"schema":"motionwright.current-sdk-source-build-composition/1","source":idx["source"],"parents":parents,"compilation":obs,"original_build_bundle":{"path":build_path,"sha256":art_specs[build_path]},"new_compilations":0,"distinct_original_compilations":1,"source_binding_errors":[e for e in source_errors if e["record"]in parents],"limits":["Compilation is shared with existing foundation observations.","Source inspection and original compilation do not prove installed use, native Host output, human review or release authority."]}
 save("sdk-source-build-composition.json",sdk)
srczip="docs/acceptance/evidence/a4-current-source-results.zip"
with zipfile.ZipFile(public_file(srczip))as z:
 b=z.read("ci/119906044984.original.log");ln=b.splitlines()[249]
 assert b"test_objective_complete_fixture_cli_counts_all_64_without_granting_release"in ln and b"... ok"in ln
 text=public_file("tooling/tests/test_creative_status_policy.py").read_text(encoding="utf-8")
 node=next(n for n in ast.walk(ast.parse(text))if isinstance(n,ast.FunctionDef)and n.name=="test_objective_complete_fixture_cli_counts_all_64_without_granting_release")
 body=ast.get_source_segment(text,node)
 for needle in('sum(counts.values()), 64','counts["implemented"], 1','counts["not_implemented"], 63','self.assertFalse(self.data["v05_release_ready"])','self.index["human_reviews"], []'):assert needle in body
 positive={"record_id":"a4-ci-0272","record_canonical_sha256":policy.canonical_digest(records["a4-ci-0272"]),"log_sha256":sha(b),"line_number":250,"line_sha256":sha(ln),"test_definition_sha256":sha(text.replace("\r\n","\n").encode()),"definition_lines":[node.lineno,node.end_lineno],"synthetic_contractually_accepted":1,"synthetic_release_ready":False,"real_product_acceptance_inferred":False}
save("positive-fixture-scope.json",positive)
rights=[]
for rel in("tooling/testdata/synthetic-first-party-viewport.png","apps/desktop/src-tauri/icons/icon.png"):
 b=public_file(rel).read_bytes();g=gitdata[BASE+":"+rel]
 assert sha(b)==g["raw_sha256"]
 with zipfile.ZipFile(public_file(srczip))as z:assert z.read("binary-source-inputs/"+rel)==b
 rights.append({"path":rel,"source_sha":BASE,"git_blob":g["blob"],"sha256":sha(b),"bytes":len(b),"raw_git_checkout_archive_equal":True,"audit_use":"Ancillary dependency integrity inspection only.","individual_rights_or_authorship_established_by_this_audit":False,"rights_limit":"Names, Git inclusion and a general repository license do not establish individual provenance or redistribution permission.","bytes_republished_by_this_audit":False})
save("audit-input-provenance.json",{"catalogs":[{"label":"catalog-"+str(i+1),"sha256":d["sha256"],"bytes":len(pinned(d)),"use":"Read original records and clause values privately; only IDs and hashes exported."}for i,d in enumerate(C["catalogs"].values())],"portfolio_sha256":C["portfolio"]["sha256"],"generated_administrative_fixtures":"None; actual candidate and retained originals were read.","ancillary_binary_inputs":rights})
stages={"compilation":{"original_run":39802244854,"job":119907366617,"step":5,"distinct_build_executions":1,"profiles":2,"new_compilations":0},"native_test":{"current_records":[r["id"]for r in records.values()if r["source"]==idx["source"]and r["execution"]["kind"]not in("source","synthetic")],"scope":"Exact record and selector scopes in record census; a native-named unit module does not imply physical Host, renderer or installed execution."},"product":{"requirement_rows":272,"scenario_rows":124,"scenario_pass_promotions":0,"package_run":39802244968,"package_workflow_result":"failure","linux_installed_create":"confirmation_missing; original failed result retained","windows":"Two process lifetimes and SQLite identity metadata in original receipt; database bytes not archived for independent readback.","macos":"Mounted/copied arm64 package; GUI_NOT_RUN; no human installed acceptance."},"publication":{"release_authorized":False,"actual_candidate_source_policy_exit_code":1,"readiness_is_acceptance":False,"formal_product_acceptance":False}}
save("four-stages.json",stages)
fields=[f for r in rows.values()for f in r["technical_assessment"]["criteria"]]
counts={"records":len(records),"reviews":len(idx["sufficiency_reviews"]),"requirements":272,"scenarios":124,"clauses":len(fields),"normative_edges":len(edges),"field_statuses":dict(collections.Counter(f["status"]for f in fields)),"row_technical_statuses":dict(collections.Counter(r["technical_assessment"]["technical_verification"]["status"]for r in rows.values())),"implementation_statuses":dict(collections.Counter(r["technical_assessment"]["implementation"]["status"]for r in rows.values())),"contract_statuses":dict(collections.Counter(r["technical_assessment"]["contract_acceptance"]["status"]for r in rows.values()))}
assert counts["field_statuses"]=={"pass":204,"partial":958,"not_run":475,"stale":15}
assert all(public_file(n).read_bytes()==b for n,b in raw.items())
receipt={"schema":"motionwright.actual-original-candidate-audit/1","started_at_utc":started,"completed_at_utc":now(),"script_sha256":sha(Path(__file__).read_bytes()),"private_configuration_sha256":sha(cfgraw),"source":idx["source"],"source_tree":tree,"remote_main_observed":remote,"candidate_is_latest_at_observation":remote==BASE,"ledger_sha256":N,"counts":counts,"catalog_originals_verified":True,"assignment_verified":True,"source_bindings_checked":source_binding_count,"unique_original_source_objects":len(gitdata),"original_source_errors":source_errors,"retained_artifact_oracle_bindings":sum(len(r["retained_artifact_definitions"])for r in source_results),"artifact_errors":artifact_errors,"artifact_files":len(art_specs),"archive_members":len(member_specs),"stale_record_count":len(stale),"history_guards":guards,"active_prs_observed":len(pr_results),"pr_paths_unmapped":sum(len(p["unmapped_paths_pending_reconciliation"])for p in pr_results),"policies_passed":4,"policies_failed":1,"scope_join_checks_valid":not(source_errors or artifact_errors),"candidate_unchanged_after":True,"inventory_is_semantic_sufficiency":False,"new_product_executions":0,"human_acceptance":False,"release_authorized":False,"result":"scope_integrity_verified"if not(source_errors or artifact_errors)else"scope_integrity_gaps"}
save("audit-result.json",receipt)
save("executed-auditor.py",Path(__file__).read_bytes())
save("receipt.private.json",{"output":str(OUT),"public_result_sha256":sha((PUB/"audit-result.json").read_bytes()),"source_errors":len(source_errors),"artifact_errors":len(artifact_errors),"readback_unchanged":True},False)
print(json.dumps({"result":receipt["result"],"counts":counts,"source_errors":source_errors[:5],"source_error_count":len(source_errors),"artifact_error_count":len(artifact_errors),"artifact_files":len(art_specs),"archive_members":len(member_specs),"output":str(OUT),"result_sha256":sha((PUB/"audit-result.json").read_bytes())}),flush=True)
