Current-source conformance observations
Source: 79929a71173d8f56422007ed944c7d6db42d879f
Seven proposed evidence records support six scoped technical field decisions.
The packet retains fresh source-path observations and actual existing CI originals from run 39905976237 attempt 1. No tests were re-executed for this packet.
Studio reports the 12-test model.test.ts file aggregate; one inspected definition is relevant. Rust contributes one named workflow authority test and six named grant tests from a single desktop_project_export binary. Repeated module executions are excluded from the credited count.
The earlier selected workflow run belongs to branch ab1e39816c67027a907a175194c8f36e2e185c97. Its four original archives and 292 source bindings were checked; equality of the integrated tree does not create a new execution at the merge commit.
Source snapshots are existing public Git blobs. Original contractual language and private coordination are omitted; criterion identity is retained by ID and digest.
Full UI-to-durable-store behavior, the relationship between creative review and external authority, and canonical workflow acceptance scenarios remain separate open obligations. Human approval and release authorization are not asserted.
Reproduction: verify every archive member against manifest.json; compare source-bindings.json to Git at the exact source; inspect the declared source spans and complete definitions; obtain the named original CI job logs and compare their digests. Repeat a test only when its applicable source/input changes or an assertion is missing.
