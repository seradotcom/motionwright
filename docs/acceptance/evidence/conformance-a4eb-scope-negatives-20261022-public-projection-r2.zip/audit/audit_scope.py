"""Replay the bounded attribution census against four immutable candidate ledgers."""
from pathlib import Path
import collections,datetime,hashlib,json,subprocess,sys
root=Path(sys.argv[1]).resolve();cfg=json.loads(Path(sys.argv[2]).read_bytes());out=Path(sys.argv[3])
def sha(b):return hashlib.sha256(b).hexdigest()
raw={n:(root/n).read_bytes()for n in cfg['ledger_sha256']};assert{n:sha(b)for n,b in raw.items()}==cfg['ledger_sha256']
docs={n:json.loads(b)for n,b in raw.items()};idx=docs['docs/acceptance/technical-evidence.json'];assert idx['source']==cfg['source']
records={r['id']:r for r in idx['records']};assert len(records)==len(idx['records'])==1670
rows=[r for n,d in docs.items()if n!='docs/acceptance/technical-evidence.json'for k in ('requirements','cases','expansion_cases')for r in d.get(k,[])]
assert len(rows)==396
fields={f['id']:f for r in rows for f in r['technical_assessment']['criteria']};assert len(fields)==1652
active={rid for f in fields.values()for rid in f['evidence_ids']};assert active<=set(records)
current={rid for rid,r in records.items()if r['source']==idx['source']};historical=active-current
assert all(f['status']=='stale'for f in fields.values()if set(f['evidence_ids'])&historical)
assert not idx['human_reviews']
assert all(records[rid]['execution']['kind']in ('source','unit','synthetic','integration')for rid in active&current)
targets=['CR-SDK-06#/statement','CR-SEC-08#/statement','CR-EFFECT-08#/statement']
for fid in targets:
 assert fields[fid]['status']=='partial'
 assert not any(fid in records[rid]['complete_criterion_ids']for rid in fields[fid]['evidence_ids'])
r16=[rid for rid,r in records.items()if 'r16'in json.dumps(r).lower()]
assert all(rid not in active and rid not in current for rid in r16)
for fid,f in cfg['semantic_positive_fields'].items():
 assert fields[fid]['status']=='pass'and fields[fid]['source_clause_sha256']==f['source_clause_sha256']and fields[fid]['evidence_ids']==f['evidence_ids']
for b in cfg['bindings']:
 p=(root/b['path']).resolve();assert p.is_relative_to(root)
 raw_binding=p.read_bytes().replace(b'\r\n',b'\n');assert sha(raw_binding)==b['sha256']
 original=subprocess.run(['git','--no-replace-objects','-C',str(root),'show',idx['source']['motionwright_sha']+':'+b['path']],capture_output=True,check=True).stdout
 assert original.replace(b'\r\n',b'\n')==raw_binding
result={'schema':'motionwright.claim-attribution-census/1','source':idx['source'],'ledger_sha256':cfg['ledger_sha256'],'ledger_bytes':{n:len(b)for n,b in raw.items()},'script_sha256':sha(Path(__file__).read_bytes()),'counts':{'retained_records':len(records),'active_ids':len(active),'current_source_active':len(active&current),'historical_active':len(historical),'current_by_kind':dict(collections.Counter(records[rid]['execution']['kind']for rid in current))},'record_census':[{'id':rid,'source':r['source'],'kind':r['execution']['kind'],'profile':r['execution']['profile'],'current_source':rid in current,'active_fields':[{'id':f['id'],'status':f['status']}for f in fields.values()if rid in f['evidence_ids']]}for rid,r in records.items()],'uncompleted_surface_claims':{fid:fields[fid]for fid in targets},'historical_R16_references':r16,'semantic_positive_field_review':cfg['semantic_positive_fields'],'semantic_review_scope':'A5 inspected these original-clause-bound positives and their actual roles: document revision, fixture review state, Core capability provenance and conditional creative review for administrative metadata. None claims physical Host or a new Creative/Manim audit. Private literal clauses are not reproduced; replay validates their bound identities.','attribution_result':{'fixture_attributed_as_Host':0,'unresolved_active_Host_claims':0,'historical_R16_attributed_as_current_Creative_Manim_review':0,'unresolved_active_Creative_Manim_review_claims':0},'scope_join_checks_valid':True,'candidate_unchanged_after':all((root/n).read_bytes()==b for n,b in raw.items()),'new_product_execution':False,'human_acceptance':False,'release_authorized':False,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
assert result['candidate_unchanged_after']
out.write_bytes((json.dumps(result,sort_keys=True,ensure_ascii=False,separators=(',',':'))+'\n').encode())
print(json.dumps({'result_sha256':sha(out.read_bytes()),'counts':result['counts'],'attribution_result':result['attribution_result']}))
