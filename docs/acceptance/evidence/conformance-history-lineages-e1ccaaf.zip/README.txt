Original public conformance ledgers and evidence indexes, retained byte for byte from Git.
The integrated prefix differs from five records and five sufficiency reviews in the earlier checkpoint.
The new composition preserves the integrated prefix, appends unique observations and scopes original parallel history to its exact original index.
Cross-lineage history-check failures remain historical facts; they are not certified repaired.
No private specifications, media, identity attestations or release approval are included.
