"""Reproduce the locked dependency direction from an exact Git commit; stdout is JSON."""
import argparse,collections,hashlib,json,os,re,subprocess,tomllib,datetime
def audit(repo,source):
 env={k:v for k,v in os.environ.items()if not k.startswith("GIT_")}
 env.update(GIT_CONFIG_NOSYSTEM="1",GIT_CONFIG_GLOBAL=os.devnull,GIT_OPTIONAL_LOCKS="0")
 bindings={}
 def read(path):
  p=subprocess.run(["git","--no-replace-objects","-c","core.fsmonitor=false","-C",repo,"show",source+":"+path],env=env,capture_output=True,check=True)
  raw=p.stdout;bindings[path]={"sha256":hashlib.sha256(raw.replace(b"\r\n",b"\n")).hexdigest(),"bytes":len(raw)};return raw.decode("utf-8")
 assert re.fullmatch("[0-9a-f]{40}",source)
 root=tomllib.loads(read("Cargo.toml"));lock=tomllib.loads(read("Cargo.lock"));read("SOURCE_LOCK.json")
 workspace=set()
 for member in root["workspace"]["members"]:
  assert "*"not in member and "?"not in member
  manifest=tomllib.loads(read(member.rstrip("/")+"/Cargo.toml"));workspace.add(manifest["package"]["name"])
 packages=lock["package"];keys=[(p["name"],p["version"],p.get("source",""))for p in packages]
 assert len(keys)==len(set(keys));byname=collections.defaultdict(list)
 for key in keys:byname[key[0]].append(key)
 graph={key:[]for key in keys};errors=[]
 for p,key in zip(packages,keys):
  for dep in p.get("dependencies",[]):
   m=re.fullmatch(r"([^ ]+)(?: ([^ ]+))?(?: \((.+)\))?",dep);assert m,dep
   name,version,origin=m.groups()
   options=[k for k in byname[name]if(version is None or k[1]==version)and(origin is None or k[2]==origin)]
   if len(options)!=1:errors.append({"package":key,"dependency":dep,"resolved":options})
   else:graph[key].append(options[0])
 assert not errors,errors
 pin="54d3459a051adbce4cae9f60c0dea8f60c824be6"
 core=[key for key in keys if key[2].startswith("git+https://github.com/seradotcom/semwright?")and key[2].endswith("#"+pin)]
 assert len(core)==16 and len(workspace)==7
 seen=set();queue=list(core)
 while queue:
  key=queue.pop()
  if key in seen:continue
  seen.add(key);queue.extend(graph[key])
 reverse=sorted(key for key in seen if key[0]in workspace)
 inbound=[{"from":key,"to":dest}for key,edges in graph.items()for dest in edges if dest[0]in workspace]
 consumers=sorted({key[0]for key,edges in graph.items()if key[0]in workspace and any(d in core for d in edges)})
 assert not reverse and all(e["from"][0]in workspace for e in inbound)
 return {"schema":"locked-core-consumer-graph/1","source_sha":source,"observed_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"input_bindings":bindings,"packages":len(keys),"resolved_edges":sum(map(len,graph.values())),"unresolved_or_ambiguous_edges":errors,"core_pin":pin,"core_packages":core,"workspace_packages":sorted(workspace),"packages_reachable_from_core":len(seen),"core_to_workspace_paths":reverse,"edges_entering_workspace":inbound,"direct_workspace_core_consumers":consumers,"checks":{"all_dependencies_resolve_uniquely":not errors,"all_core_roots_share_fixed_public_pin":len(core)==16,"all_workspace_manifests_read":len(workspace)==7,"no_transitive_core_dependency_on_workspace":not reverse,"workspace_inbound_edges_have_workspace_owners":all(e["from"][0]in workspace for e in inbound),"workspace_direct_core_consumers_present":bool(consumers)},"scope":"Source dependency direction only; no Host, renderer, installed, human or release acceptance."}
if __name__=="__main__":
 p=argparse.ArgumentParser();p.add_argument("--repo",required=True);p.add_argument("--source",required=True);a=p.parse_args();print(json.dumps(audit(a.repo,a.source),sort_keys=True,indent=2))
