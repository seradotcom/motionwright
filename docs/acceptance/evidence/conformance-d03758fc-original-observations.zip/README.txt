Bounded technical observations for integrated Motionwright d03758fc57d84ab9c9557b867fd0ad79b5767566.
Records identify current Git bytes, source bodies, actual CI run/job/attempt/checkout or the actual local process, and selected assertions.
Original CI byte slices retain offsets, lengths and hashes. Full original logs remain separately retained and identified by endpoint and digest; these excerpts alone are not the complete logs.
A distinct clean-source 16-method local process passed. Thirteen history/currency methods and three cost-claim controls are selected separately; synthetic cost inputs are not benchmark results.
Historical failed executions retain their original source and exit code. Sixteen anchored editorial annotations clarify copied historical notes without altering their original records or decisions.
Static source observations are not dynamic test executions. Counts are scoped selections, not whole-job totals, and overlapping groups must not be summed as unique tests.
This archive contains public-source observations and clause hashes, without private specification text, acceptance media, human signatures or release authorization.
