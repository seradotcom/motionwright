from pathlib import Path
import hashlib,json,re,zipfile
root=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
jl=lambda p:json.loads(p.read_bytes())
m=jl(root/'manifest.json');files={x['path']:x for x in m['files']}
assert {p.relative_to(root).as_posix()for p in root.rglob('*')if p.is_file()and p.name!='manifest.json'}==set(files)
for rel,x in files.items():
 b=(root/rel).read_bytes();assert len(b)==x['bytes']and sha(b)==x['sha256']
obs=jl(root/'review/observations.json');prov=jl(root/'review/provenance.json')
assert obs['source']['motionwright_sha']=='79929a71173d8f56422007ed944c7d6db42d879f'
for a in prov['original_archives']:
 p=root/a['member'];assert sha(p.read_bytes())==a['sha256']
 with zipfile.ZipFile(p)as z:
  assert z.testzip()is None and len(z.namelist())==len(a['members'])
  for x in a['members']:assert sha(z.read(x['name']))==x['sha256']
names=set();count=0
for o in obs['observations']:
 logs=[]
 for x in o['logs'].values():
  b=(root/x['member']).read_bytes();assert sha(b)==x['sha256'];logs.append(b.decode())
 s='\n'.join(logs);observed=re.findall(r'(?m)^test ([A-Za-z0-9_:]+) \.\.\. ok\r?$',s)
 assert set(observed)==set(o['selectors'])and len(observed)==o['passed']
 assert o['original_terminal_line']in s and o['exit_code']==0
 names.update(observed);count+=len(observed)
for x in obs['method_definitions']+obs['supporting_helpers']:
 b=(root/'source'/x['path']).read_bytes();assert sha(b)==x['file_sha256']
 body=''.join(b.decode().splitlines(keepends=True)[x['start_line']-1:x['end_line']]);assert sha(body.encode())==x['body_sha256']
assert len(names)==9 and count==18 and len(obs['observations'])==10
print(json.dumps({'custody_validation':'PASS','unique_methods':9,'original_invocations':18,'new_product_tests':0,'criterion_promotions':0,'human_acceptance':False,'release_authorized':False}))
