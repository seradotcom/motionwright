# Selected SQLite originals for a fixed source

Source 79929a71173d8f56422007ed944c7d6db42d879f; run 39905976216, attempt 1. This archive retains three original CI archives, their extracted bytes, API metadata, seven exact source inputs and inspected method spans.

Windows and macOS each executed nine methods across five commands. G0 checked source identity only. The same migration method also appears in a separate migration evidence package; aggregate counts must deduplicate method identities. No product tests were rerun during admission.

Run python -B verify.py after extraction to verify custody and the recorded nominal outputs. The scopes and exclusions are in review/observations.json. These observations supplement existing evidence without closing an entire criterion or acceptance scenario. Process crash, physical power interruption, platform path authority, native production and installed-product recovery are outside these executions. No human or release approval is asserted.
