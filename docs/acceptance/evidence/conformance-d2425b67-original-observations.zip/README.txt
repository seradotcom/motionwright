Bounded technical observations for integrated Motionwright d2425b67330263b8621f39d6de0fd24826c70907.
Each observation identifies original source bytes, test bodies, actual run/job or local process, and selected assertions.
CI observations retain byte offsets, lengths and hashes into original logs. Authorized originals are identified by endpoint and digest; these excerpts alone are not the complete original logs.
Local observations are explicitly derived from retained original receipts; personal executable paths are omitted and original receipt/command hashes retained.
Source checks are static observations, not additional dynamic tests. Counts within records are selected assertions, not entire-job test totals and must not be summed across overlapping groups.
The earlier failing 18-method local process remains a failure; a distinct 13-method process passed. No private acceptance scenario was thereby performed.
This archive contains public-code observations and hashes only. It contains no private requirement text, acceptance inputs, human signature or release authorization.
